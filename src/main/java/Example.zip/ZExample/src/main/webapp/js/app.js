'use strict';

var AngularSpringApp = {};

var App = angular.module('AngularSpringApp', ['ngRoute' , 'ui.bootstrap','angularFileUpload']);

App.config(['$routeProvider', function ($routeProvider) {
    
    $routeProvider.when('/about', {
        templateUrl: 'html/about.html',
        controller: 'aboutCtrl'
    });
    
    $routeProvider.otherwise({redirectTo: '/about'});
}]);
App.controller('indexCtrl',function($scope,$http){
	console.log('indexCtrl');
});
App.controller('aboutCtrl',function($scope,$http,$upload,$sce){
	$scope.getAll = function() {
		$http({
			method : "GET",
			headers : {
				'Cache-Control' : 'no-cache',
				'Pragma': 'no-cache'						
			},
			url : "/spring-services/application/srt",
			params : {'str' :'lakshman'}
		}).success(function(data) {
			console.log(data);
		}).error(function(data, status) {
			console.log(data);
		});
	};
	$scope.getAll();
	$scope.printPdfDoc = function() {
		$http.get('/spring-services/application/print', {responseType: 'arraybuffer'})
		   .success(function (data) {
			   var file = new Blob([data], {type: 'application/pdf'});
			   var fileURL = URL.createObjectURL(file);
//			   $scope.pdfContent = fileURL;
			   $scope.pdfContent = $sce.trustAsResourceUrl(fileURL);
			   console.log($scope.pdfContent);
			   window.open(fileURL, '_blank', 'scrollbars=1, resizable=1, top='+10+', left='+10+', width='+600+', height='+500+'',true);
		});
	};
	$scope.downloadCsvFile = function() {
		$http.get('/spring-services/application/export')
		.success(function (data) {
			var element = angular.element('<a/>');
			element.attr({
				href: 'data:attachment/csv;charset=utf-8,' + encodeURI(data),
				target: '_blank',
				download: 'search_results.csv'
			})[0].click();
		});
	};
	$scope.exportExcelData = function() {
		var form = document.createElement("form");
	    form.setAttribute("method", "POST");
//	    form.setAttribute("target", "_self");
	    form.setAttribute("action", "/spring-services/application/exportDataToExcel");
//		var hiddenField = document.createElement("input");
//        hiddenField.setAttribute("type", "hidden");
//        hiddenField.setAttribute("name", "fileData");
//        hiddenField.setAttribute("value",angular.toJson(file));
//        form.appendChild(hiddenField);
	    document.body.appendChild(form);
	    form.submit();
	};
	$scope.exportCsvData = function() {
		var form = document.createElement("form");
		form.setAttribute("method", "POST");
		form.setAttribute("action", "/spring-services/application/exportDataToCsv");
		document.body.appendChild(form);
		form.submit();
	};
	$scope.selectedFiles = [];
	$scope.selectedDocFiles = [];
	$scope.resetInputFile = function() {
		$scope.selectedFiles = [];
		$scope.selectedDocFiles = [];
		var elems = document.getElementsByTagName('input');
		for (var i = 0; i < elems.length; i++) {
			if (elems[i].type === 'file') {
				elems[i].value = null;
			}
		}
	};
	$scope.onFilesSelect = function($files) {
		$scope.selectedFiles = [];
		$scope.selectedFiles = $files;
		$scope.tableRowData = [];
		$scope.tableHeaders = [];
		$scope.list = [];
	};
	$scope.uploadFiles = function() {
		$upload.upload({
			url : '/spring-services/application/upload',
			method : 'POST',
			headers : {
				'Content-Type' : 'multipart/form-data'
			},
			file : $scope.selectedFiles[0],
			fileFormDataName : 'file'
		}).success(function(data) {
			angular.forEach(data,function(listOfObjs){
				$scope.tableHeaders = [];
				$scope.tableRowData = [];
				angular.forEach(listOfObjs.fieldData,function(objsData){
					$scope.tableHeaders = listOfObjs.fieldData[0].dataColumn;
					var localData = [];
					angular.forEach(objsData.dataColumn,function(aaaaaaaa){
						localData.push(aaaaaaaa);
					});
					$scope.tableRowData.push(localData);
				});
				$scope.list.push({'tableHeaders' : $scope.tableHeaders, 'tableRowData' : $scope.tableRowData});
			});
		}).error(function(data, status) {
			console.log(data, status);
		});
	};
	$scope.onDocFilesSelect = function($files) {
		$scope.selectedDocFiles = [];
		$scope.selectedDocFiles = $files;
	};
	$scope.stringData = '';
	$scope.uploadDocFiles = function() {
		$upload.upload({
			url : '/spring-services/application/uploadDocfile',
			method : 'POST',
			headers : {
				'Content-Type' : 'multipart/form-data'
			},
			file : $scope.selectedDocFiles[0],
			fileFormDataName : 'file'
		}).success(function(data) {
			$scope.stringData = data;
			console.log(data);
		}).error(function(data, status) {
			console.log(data, status);
		});
	};
	$http({
		method : "GET",
		headers : {
			'Cache-Control' : 'no-cache',
			'Pragma': 'no-cache'						
		},
		url : "/spring-services/application/getUser"
	}).success(function(data) {
		$scope.lll = data;
	}).error(function(data, status) {
		console.log(data);
	});
	
	$scope.filterData = function(name,work,location) {
		console.log(name);
		console.log(work);
		console.log(location);
		$scope.dataListss = [];
		angular.forEach($scope.dataLists,function(data){
			if((!angular.isUndefined(name) && name != '' && name.length != 0 && data[0].value.indexOf(name) > -1 )||
					(!angular.isUndefined(work) && work != '' && work.length != 0 && data[1].value.indexOf(work) > -1 )||
							(!angular.isUndefined(location) && location != '' && location.length != 0 && data[2].value.indexOf(location) > -1)){
				$scope.dataListss.push(data);
			}
		});
		if((angular.isUndefined(name) || name === '' || name.length === 0) &&
				(angular.isUndefined(work) || work === '' || work.length === 0 ) &&
					(angular.isUndefined(location) || location === '' || location.length === 0 )){
			$scope.dataListss = angular.copy($scope.dataLists);
		}
	};
	
	$scope.dataList = [{'name':'lakshman','work':'java','location':'hyd'},
	                   {'name':'ram','work':'java','location':'hyderabad'},
	                   {'name':'chinni','work':'java','location':'bang'},
	                   {'name':'chinnu','work':'html','location':'hyd'},
	                   {'name':'pandu','work':'java','location':'bang'},
	                   {'name':'pavan','work':'javascript','location':'banglore'},
	                   {'name':'santosh','work':'html','location':'hyderabad'},
	                   {'name':'lakshman','work':'java','location':'chen'}];
	$scope.dataLists = [[{'value':'lakshman','index':'0'},{'value':'java','index':'1'},{'value':'hyd','index':'2'}],
	                   [{'value':'ram','index':'0'},{'value':'java','index':'1'},{'value':'hyderabad','index':'2'}],
	                   [{'value':'chinni','index':'0'},{'value':'java','index':'1'},{'value':'bang','index':'2'}],
	                   [{'value':'chinnu','index':'0'},{'value':'html','index':'1'},{'value':'hyd','index':'2'}],
	                   [{'value':'pandu','index':'0'},{'value':'java','index':'1'},{'value':'bang','index':'2'}],
	                   [{'value':'pavan','index':'0'},{'value':'javascript'},{'value':'banglore','index':'2'}],
	                   [{'value':'santosh','index':'0'},{'value':'html','index':'1'},{'value':'hyderabad','index':'2'}]];
	$scope.dataListss = angular.copy($scope.dataLists);
}).directive("scroll", function($window) {
	return {
		controller : function($scope) {
			angular.element($window).bind("scroll", function() {
				if (this.pageYOffset >= 600) {
//					$scope.changeFlag(true);
					console.log('Scrolled below header.');
				} else {
//					$scope.changeFlag(false);
					console.log('Header is in view.');
				}
	            $scope.$apply();
			});
		}
	};
});
/*<a href="" class="scrollup" ng-click="scrollTop()" ng-show="boolChangeClass">scroll</a>
<style>
.scrollup {
width: 40px;
height: 40px;
opacity: 0.6;
position: fixed;
bottom: 50px;
right: 90px;
text-indent: -9999px;
background-color: red;
}
</style>
*/