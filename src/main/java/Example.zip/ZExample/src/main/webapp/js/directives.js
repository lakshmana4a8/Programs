'use strict';

var App = angular.module('AngularSpringApp');

App.directive('customGrid',function(){
	return {
		restrict : 'EA',
		replace : true,
		scope : {
			tableHeaders : '=tableHeaders',
			tableData : '=tableData'
		},
		templateUrl : 'html/layout.html'
	}
});