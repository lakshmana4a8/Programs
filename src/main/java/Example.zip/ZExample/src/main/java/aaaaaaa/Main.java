package aaaaaaa;

import java.util.Scanner;

public class Main {
    @SuppressWarnings("resource")
    public static void main(String args[]){
        int hours,mins;
        System.out.println("Enter the Time(hours) : ");
        Scanner dx = new Scanner(System.in);
        hours = dx.nextInt();
        System.out.println("Enter the time(mins) : ");
        Scanner fx = new Scanner(System.in);
        mins = fx.nextInt();
        if(hours>=0 && hours<=12){
            if(mins == 60) {
                mins = 0;
            }
            if(mins>=0 && mins<=59){
                double hDegrees = (hours * 30) + (mins * 0.5);
                double mDegrees = mins * 6;
                double diff  = Math.abs(hDegrees - mDegrees);
                System.out.println("The angle between sticks is (degrees) : "+diff);
                System.out.println("The angle between sticks is (degrees) simple : "+(30 * (hours - (mins/5)) + (mins/2)));
                System.out.println(((hours*60 + mins)*0.5) - (mins*6));
                if (diff > 180){ 
                    diff = 360 - diff;
                    System.out.println("The angle between sticks is (degrees) : "+diff);
                    System.out.println("The angle between sticks is (degrees) simple : "+(30 * (hours - (mins/5)) + (mins/2)));
                }
            }
        }
        else{
            System.out.println("Wrong input ");
        }
    }
}
