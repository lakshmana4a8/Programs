package threads;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

public class ThreadShutDown extends Thread
{
    private ExecutorService executorService;

//    final AnnotationConfigApplicationContext annotationConfigContext
    public ThreadShutDown(final ExecutorService executorService)
    {
        this.executorService = executorService;
//        this.annotationConfigContext = annotationConfigContext;
    }

    @Override
    public void run()
    {
        this.executorService.shutdown();
        try
        {
            while (!this.executorService.isTerminated())
            {
                this.executorService.awaitTermination(10, TimeUnit.SECONDS);
            }

//            annotationConfigContext.close();
        }
        catch (final InterruptedException exception)
        {
            this.executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
        catch (final Exception exception)
        {
            Thread.currentThread().interrupt();
        }
    }
}
