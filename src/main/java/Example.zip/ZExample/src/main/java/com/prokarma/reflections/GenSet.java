package com.prokarma.reflections;
import java.lang.reflect.Array;  

public class GenSet<E>   {  
   private E[] a;  

   public GenSet(Class<E[]> clazz, int length)  {  
      a = clazz.cast(Array.newInstance(clazz.getComponentType(), length));  
   }  

   public static void main(String[] args)  {  
      GenSet<String> foo = new GenSet<String>(String[].class, 1);  
      String[] bar = foo.a;  
      foo.a[0] = "xyzzy";  
      String baz = foo.a[0]; 
      System.out.println(foo.a[0]);
   }  
}