package com.prokarma.app.file;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.prokarma.app.json.entity.FileData;

public interface FileUploadService {
	List<FileData> handleFileUpload(final MultipartFile file);

	byte[] getFile();

    String handleDocFileUpload(MultipartFile file) throws IOException;
}
