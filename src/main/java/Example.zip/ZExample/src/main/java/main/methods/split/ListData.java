package main.methods.split;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;

public class ListData {
	public static void main(String[] args) {
		final List<String> dataList = new ArrayList<String>();
		dataList.add("a\"a");
		dataList.add("bb");
		dataList.add("cc");
		dataList.add("dd");
		System.out.println(JSONArray.toJSONString(dataList));
		System.out.println(toString(dataList));
	}

	private static String toString(List<String> dataList) {
		StringBuffer buffer = new StringBuffer("[");
		int len = 0;
		for(String data : dataList) {
			buffer.append("\"");
			buffer.append(data);
			buffer.append("\"");
			len++;
			if(len != dataList.size()) {
				buffer.append(",");
			}
		}
		buffer.append("]");
		return buffer.toString();
	}
}
