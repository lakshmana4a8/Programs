package main.methods;

public class Enum {
	
	public enum UserStatus {
		PENDING("P zsrdg"), DELETED("D"), ACTIVE("A"), INACTIVE("I");
	 
		private String statusCode;
	 
		private UserStatus(String s) {
			System.out.println("settter : "+s);
			statusCode = s;
		}
	 
		public String getStatusCode() {
			System.out.println("getter : "+statusCode);
			return statusCode;
		}
	}
	public static void main(String[] args) {
		for(UserStatus u : UserStatus.values()) {
			System.out.println(u+" : "+u.getStatusCode());
		}
	}
}
