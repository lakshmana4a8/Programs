package com.prokarma.app.json.entity;

import java.util.List;

public class FileData {
	private List<DataRow> fieldData; // Field Data

	public FileData() {
	}

	public List<DataRow> getFieldData() {
		return fieldData;
	}

	public void setFieldData(List<DataRow> fieldData) {
		this.fieldData = fieldData;
	}

	@Override
	public String toString() {
		return fieldData.toString();
	}
}
