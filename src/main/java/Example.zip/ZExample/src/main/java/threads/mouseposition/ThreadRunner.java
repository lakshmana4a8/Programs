package threads.mouseposition;

public class ThreadRunner
{
    public static void main(String[] args)
    {
        for (int i = 0; i < 3; i++)
        {
            Thread t1 = new Thread(new MousePosition());
            t1.setName("THREAD"+i);
            t1.start();
        }
    }
}
