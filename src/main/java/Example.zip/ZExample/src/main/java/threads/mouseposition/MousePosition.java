package threads.mouseposition;

import java.awt.MouseInfo;
import java.awt.PointerInfo;

public class MousePosition implements Runnable
{
    int i = 1;
    @SuppressWarnings("static-access")
    @Override
    public void run()
    {
        while(!Thread.currentThread().isInterrupted()) { // true for continuous running, i < 2 for once
            try {
                PointerInfo mouseLocation = MouseInfo.getPointerInfo();
                int x = mouseLocation.getLocation().x;
                int y = mouseLocation.getLocation().y;
                Thread.currentThread().sleep(1500L);
                if(Thread.currentThread().getName().equalsIgnoreCase("THREAD1") || Thread.currentThread().getName().equalsIgnoreCase("THREAD2")) {
                    Thread.currentThread().interrupt();
//                    Thread.currentThread().join();
//                    throw new InterruptedException();
                }
                System.out.println("X:"+x+" Y:"+y+" at time "+Thread.currentThread().getName());
                getName();
                i++;
            } catch(Exception e) {
                System.out.println("Exception caught : "+e);
//                Thread.currentThread().run();
            }
          }
    }
    public void getName() {
        System.out.println("lakshman");
    }
}