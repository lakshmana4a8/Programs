package main.methods.split;

import java.util.StringTokenizer;

public class SplitString {
	public static void main(String[] args) {
		/*String data = "[\"aaa[a\",\"aaa[a\",\"aaaa\",\"aaaa\",\"aaaa\",\"aaaa\",\"aaaa\",\"aaaa\",\"aaaa\",\"aaaa\"]";
		data = data.replaceFirst("[", "");
		data = data.replace("]", "");
		System.out.println(data);*/
		String myName = "[\"aaaa\",\"bbbb\",\"cccc\",\"dddd\",\"eeee\"]";
		myName = myName.substring(0,0)+' '+myName.substring(1);
		myName = myName.substring(0,(myName.lastIndexOf("]")))+' ';
		StringTokenizer st2 = new StringTokenizer(myName, ",");
		System.out.println(myName);
		while (st2.hasMoreElements()) {
			System.out.println(st2.nextElement().toString().trim());
		}
	}
}
