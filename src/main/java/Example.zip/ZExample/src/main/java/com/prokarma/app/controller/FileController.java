package com.prokarma.app.controller;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.prokarma.app.exportdata.ExportData;
import com.prokarma.app.file.FileUploadService;
import com.prokarma.app.json.entity.FileData;

@Controller
@RequestMapping()
public class FileController {
	@Autowired
	private FileUploadService fileUploadService;
	@Autowired
	private ExportData exportData;
	
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
    public @ResponseBody
    ResponseEntity<List<FileData>> handleFileUpload(@RequestParam("file") final MultipartFile file) {
        final List<FileData> response = fileUploadService.handleFileUpload(file);
        final ResponseEntity<List<FileData>> successResponse = new ResponseEntity<List<FileData>>(response, HttpStatus.OK);
        return successResponse;
    }
	
	@RequestMapping(value = "/uploadDocfile", method = RequestMethod.POST)
	public @ResponseBody
	ResponseEntity<String> handleDocFileUpload(@RequestParam("file") final MultipartFile file) throws IOException {
	    final String response = fileUploadService.handleDocFileUpload(file);
	    final ResponseEntity<String> successResponse = new ResponseEntity<String>(response, HttpStatus.OK);
	    return successResponse;
	}
	@RequestMapping(value = "/getUser", method = RequestMethod.GET)
	public @ResponseBody
	String getUser() {
		System.out.println("in controller");
		return "lakshmna";
	}
	@RequestMapping(value = "/exportPdfDoc", method = RequestMethod.GET)
	public @ResponseBody
	ResponseEntity<byte[]> exportPdfDoc() {
		System.out.println("in controller");
		InputStream inputStream = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            inputStream = new FileInputStream("files/AngularJS_Succinctly.pdf");
            byte[] buffer = new byte[1024];
            baos = new ByteArrayOutputStream();
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
		final ResponseEntity<byte[]> successResponse = new ResponseEntity<byte[]>(baos.toByteArray(), HttpStatus.OK);
        return successResponse;
	}
	
	@RequestMapping(value = "/exportDataToExcel", method = RequestMethod.POST)
	public void exportDataToExcel(final HttpServletResponse response) {
		exportData.exportDataToExcel(response);
	}
	
	@RequestMapping(value = "/exportDataToCsv", method = RequestMethod.POST)
	public void exportDataToCsv(final HttpServletResponse response) {
		System.out.println("exportDataToCsv controller");
		exportData.exportDataToCsv(response);
	}
	@RequestMapping(value = "/srt", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<String> testString(@RequestParam("str") String str) {
	    System.out.println("======"+str);
	    final ResponseEntity<String> successResponse = new ResponseEntity<String>(str+"  "+"aaaaaaaaaaaa", HttpStatus.OK);
	    return successResponse;
	}
	
	@RequestMapping(value = "print", method = RequestMethod.GET)
	@ResponseBody
	public HttpEntity<byte[]> print() throws IOException, URISyntaxException {
		System.out.println(Paths.get(this.getClass().getResource("/teams.pdf").toURI()));
		InputStream inputStream = new FileInputStream(Paths.get(this.getClass().getResource("/teams.pdf").toURI()).toString());
		byte[] documentBody = IOUtils.toByteArray(inputStream);
	    HttpHeaders header = new HttpHeaders();
	    header.setContentType(new MediaType("application", "pdf"));
	    header.set("Content-Disposition","attachment; filename=example.pdf");
	    header.setContentDispositionFormData("attachment", "sample.pdf");
	    header.setContentLength(documentBody.length);
	    return new HttpEntity<byte[]>(documentBody, header);
	}
	@RequestMapping(value="/export", method = RequestMethod.GET)
	@ResponseBody
	public HttpEntity<byte[]> export() throws IOException, URISyntaxException {
		Path path = Paths.get(this.getClass().getResource("/Equipments.csv").toURI());
		byte[] documentBody = Files.readAllBytes(path);
	    HttpHeaders header = new HttpHeaders();
	    header.setContentType(new MediaType("application", "octet-stream"));
	    header.set("Content-Disposition","attachment; filename=example.csv");
	    header.setContentLength(documentBody.length);
	    return new HttpEntity<byte[]>(documentBody, header);
	}
}
