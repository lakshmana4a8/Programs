package main.methods.java;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class DocFile
{
    static String filePath = "xprk259/New Text Document.doc";
    public static void main(String[] args) throws IOException {
        /*try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(filePath, true)))) {
            out.println("the text");
        }catch (IOException e) {
            //exception handling left as an exercise for the reader
        }*/
        try {
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(filePath, true)));
            out.println("This is the text contents");
            out.close();
        } catch (IOException e) {
            //exception handling left as an exercise for the reader
        }
        /*FileOutputStream fop = null;
        File file;
        String content = "This is the text contents";
        try {
            file = new File(filePath);
            fop = new FileOutputStream(file);
            if (!file.exists()) {
                file.createNewFile();
            }
            byte[] contentInBytes = content.getBytes();
            fop.write(contentInBytes);
            fop.flush();
            fop.close();
            System.out.println("Done");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (fop != null) {
                    fop.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }*/
        
        @SuppressWarnings("resource")
        FileInputStream Fin=new FileInputStream(filePath);
        int j;
        while((j=Fin.read())!=-1)
        System.out.print((char)j);
    }
}
