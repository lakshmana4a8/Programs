package com.prokarma.reflections;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.util.ReflectionUtils;


public class Main
{
    public static void main(String[] args) throws Exception
    {
        Test test = new Test();
        Test1 test1 = new Test1();
        test1.setNumber("lakshman");
        test.setName("lakshman");
        test.setFullName("SL");
        test.setNumber(122);
        test.setTest1(test1);
        
        System.out.println("---------------");
        Method method1;
        method1 = ReflectionUtils.findMethod(test.getTest1().getClass(), "getNumbers");
        System.out.println(method1);
        System.out.println(method1.invoke(test.getTest1()));
        Object value = ReflectionUtils.invokeMethod(method1, test.getTest1().getClass());
        System.out.println(value);
        System.out.println("---------------");
        
        System.out.println(getValueFromStaticMethod(test, "FULL_NAME"));
        System.out.println(getValueFromStaticField(test.getClass(), "TEST_STATIC_VAR"));
        System.out.println(getValueFromMethod(test, "getFullParmMap"));
        System.out.println(getObjectFromClassname(test.getClass(), "ROWMAPPER_CLASS_NAME"));
        Method method;
        method = test.getClass().getMethod("getName");
        System.out.println("==========================");
        System.out.println("getName 1: "+ method.invoke(test));
        System.out.println("getName 2: "+ getValueFromMethod(test, "getName"));
        System.out.println("==========================");
        method = test.getClass().getMethod("getFullName");
        System.out.println("==========================");
        System.out.println("getFullName 1: "+ method.invoke(test));
        System.out.println("getFullName 2: "+ getValueFromMethod(test, "getFullName"));
        System.out.println("==========================");
        method = test.getClass().getMethod("getNumber");
        System.out.println("==========================");
        System.out.println("getNumber 1: "+ method.invoke(test));
        System.out.println("getNumber 2: "+ getValueFromMethod(test, "getNumber"));
        System.out.println("==========================");
    }
    public static Object getValueFromStaticMethod(final Object object, String methodName)
    {
        final Field field = ReflectionUtils.findField(object.getClass(), methodName);
        return ReflectionUtils.getField(field, object);
    }
    public static Object getValueFromMethod(final Object object, final String methodName)
    {
        final Method method = ReflectionUtils.findMethod(object.getClass(), methodName);
        return ReflectionUtils.invokeMethod(method, object);
    }
    @SuppressWarnings("rawtypes")
    public static Object getValueFromStaticField(final Class object, final String methodName)
    {
        final Field field = ReflectionUtils.findField(object, methodName);
        return ReflectionUtils.getField(field, object);
    }
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static Object getObjectFromClassname(Class object, String className) throws Exception
    {
        final Field field = ReflectionUtils.findField(object, className);
        try
        {
            final String classNameFieldValue = ReflectionUtils.getField(field, object).toString();
            final Class classForGivenString = Class.forName(classNameFieldValue);
            final Class[] emptyClass = null;
            final Constructor constructor = classForGivenString.getConstructor(emptyClass);
            final Object[] emptyObject = null;
            return constructor.newInstance(emptyObject);
        }

        catch (final Exception e)
        {
            throw new Exception();
        }
    }
}
