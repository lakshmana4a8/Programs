package main.methods;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.MessageFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;

public class ExportToExcel {
	static HSSFWorkbook wb = new HSSFWorkbook();
	private static HSSFFont boldFont = null;
	private static HSSFFont normalFont = null;
	static int row = 0;
	public static void main(String[] args) throws IOException {
		HSSFSheet personSheet = wb.createSheet("TableDataList");
		personSheet.setDefaultColumnWidth(20); //sheet.setDefaultColumnWidth(15);

		createRows(personSheet);
		row++;
		createTableHeaderRow(personSheet);
		createTableDataRows(personSheet);

		String outputDirPath = "Y:/NAFD/ZExample/xprk259/aaaaaaaa.xls";
		FileOutputStream fileOut = new FileOutputStream(outputDirPath);
		wb.write(fileOut);
		fileOut.close();
	}
	
	private static void createRows(HSSFSheet personSheet) {
		createRow(personSheet,"Row1","Value1");
		createRow(personSheet,"Row2","Value2");
		createRow(personSheet,"Row3","Value3");
		createRow(personSheet,"Row4","Value4");
		createRow(personSheet,"Row5","Value5");
	}

	private static void createRow(HSSFSheet personSheet, String string, String string2) {
		HSSFCellStyle style = getColumnStyle((short) 0);;
		HSSFRow headerRow = personSheet.createRow(row);
		HSSFCell nameHeaderCell = headerRow.createCell(0);
		nameHeaderCell.setCellValue(string);
		nameHeaderCell.setCellStyle(style);
		HSSFCell nameHeaderCell1 = headerRow.createCell(1);
		nameHeaderCell1.setCellValue(string2);
		nameHeaderCell1.setCellStyle(style);
		row++;
	}

	private static void createTableHeaderRow(HSSFSheet personSheet) {
		HSSFCellStyle style = getColumnStyle((short) 0);;
		HSSFRow headerRow = personSheet.createRow(row);
		for(int k=0;k<6;k++){
			HSSFCell nameHeaderCell = headerRow.createCell(k);
			nameHeaderCell.setCellValue("Header Row"+k);
			nameHeaderCell.setCellStyle(style);
		}
		row++;
	}

	private static void createTableDataRows(HSSFSheet personSheet) {
		for(int j=0; j<10;j++){
			HSSFRow dataRow = personSheet.createRow(row);
			for(int k=0;k<6;k++){
				HSSFCell dataNameCell = dataRow.createCell(k);
				dataNameCell.setCellValue("Table Data Row"+j);
			}
			row++;
		}
	}
	
	private static HSSFCellStyle getColumnStyle(short s) {
		final HSSFCellStyle columnHeaderStyle = wb.createCellStyle();
		columnHeaderStyle.setFillBackgroundColor(getHeaderColor());
		columnHeaderStyle.setAlignment(CellStyle.ALIGN_LEFT);
		columnHeaderStyle.setFillForegroundColor(getHeaderColor());
		columnHeaderStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		columnHeaderStyle.setBorderLeft((short) 1);
		columnHeaderStyle.setBorderRight((short) 1);
		columnHeaderStyle.setBorderTop((short) 1);
		columnHeaderStyle.setBorderBottom((short) 1);
		columnHeaderStyle.setDataFormat(s);
		columnHeaderStyle.setFont(getBoldFont());
		columnHeaderStyle.setWrapText(true);
		columnHeaderStyle.setVerticalAlignment((short) 0);
		return columnHeaderStyle;
	}
	
	private static HSSFFont getBoldFont() {
		if (boldFont == null) {
			boldFont = wb.createFont();
			boldFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			boldFont.setFontHeightInPoints((short) 8);
		}
		return boldFont;
	}
	
	@SuppressWarnings("unused")
	private static HSSFFont getFont() {
		if (normalFont == null) {
			normalFont = wb.createFont();
			normalFont.setFontHeightInPoints((short) 8);
		}
		return normalFont;
	}

	private static short getHeaderColor() {
		final HSSFPalette palette =  wb.getCustomPalette();

		final byte redValue = (byte) 120;
		final byte greenValue = (byte) 200;
		final byte blueValue = (byte) 0;
//		final byte redValue = (byte) 236;
//		final byte greenValue = (byte) 172;
//		final byte blueValue = (byte) 0;

		// choose a seed color index
		final short colorIndex = HSSFColor.RED.index + 1;
		palette.setColorAtIndex(colorIndex, redValue, greenValue, blueValue);
		return colorIndex;
	}

	public static String format(final String pattern, final Object... arguments) {
		return MessageFormat.format(pattern, arguments);
	}
}
