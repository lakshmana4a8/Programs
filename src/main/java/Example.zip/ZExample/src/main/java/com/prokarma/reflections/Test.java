package com.prokarma.reflections;

import java.util.HashMap;
import java.util.Map;

public class Test
{
    public static final String ROWMAPPER_CLASS_NAME = "com.prokarma.app.controller.FileController";
    private String name;
    private String fullName;
    private int number;
    private Test1 test1;
    public Test1 getTest1()
    {
        return test1;
    }
    public void setTest1(Test1 test1)
    {
        this.test1 = test1;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public String getFullName()
    {
        return fullName;
    }
    public void setFullName(String fullName)
    {
        this.fullName = fullName;
    }
    public int getNumber()
    {
        return number;
    }
    public void setNumber(int number)
    {
        this.number = number;
    }
    
    public static final String FULL_NAME = "S Lakshmana Rao";
    public static final String TEST_STATIC_VAR = "test_static_var";
    
    @SuppressWarnings({"rawtypes", "unchecked"})
    public Map getFullParmMap()
    {
        final Map parmMap = new HashMap();
        parmMap.put("name", name);
        parmMap.put("fullName", fullName);
        parmMap.put("number", number);
        return parmMap;
    }
    
    @Override
    public String toString()
    {
        return "Test [name=" + name + ", fullName=" + fullName + ", number=" + number + "]";
    }
}
