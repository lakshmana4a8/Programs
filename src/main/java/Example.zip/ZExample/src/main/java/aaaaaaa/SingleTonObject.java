package aaaaaaa;

public class SingleTonObject
{
    private static SingleTonObject myObj;
    
    static{
        myObj = new SingleTonObject();
    }
     
    private SingleTonObject(){
     
    }
     
    public static SingleTonObject getInstance(){
        return myObj;
    }
     
    public void testMe(){
        System.out.println("Hey.... it is working!!!");
    }
     
    public static void main(String a[]){
        SingleTonObject ms = getInstance();
        System.out.println(ms.hashCode());
        
        SingleTonObject ms1 = getInstance();
        System.out.println(ms1.hashCode());
        
        ms.testMe();
    }
}
