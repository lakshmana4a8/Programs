package main.methods;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.prokarma.app.json.entity.DataColumn;
import com.prokarma.app.json.entity.DataRow;

public class XlsOrXlsx {
	public static void main(String[] args) throws InvalidFormatException, IOException {
		List<Object> objList = new ArrayList<Object>();
		File file1 = new File("files/NAFD Test File.xlsx");
		FileInputStream fis1 = new FileInputStream(file1);
		Workbook workbook1 = WorkbookFactory.create(fis1);
		int numberOfSheets1 = workbook1.getNumberOfSheets();
		for (int index = 0; index < numberOfSheets1; index++){
			final Sheet sheet = workbook1.getSheetAt(index);
			short lastCell = 0;
			for (final Row row : sheet) {
	        	if(lastCell < row.getLastCellNum()) {
	        		lastCell = row.getLastCellNum();
	        	}
	        }
			for (final Row row : sheet){
				List<String> list = new ArrayList<String>();
				for (short count = 0; count < lastCell; count++) {
					final Cell cell = row.getCell(count, Row.CREATE_NULL_AS_BLANK);
					final DataFormatter dataFormatter = new DataFormatter();
					// CellReference cellReference = new CellReference(dataCell);
					final String cellValue = dataFormatter.formatCellValue(cell);
					list.add(cellValue);
				}
				objList.add(list);
			}
		}
		
		
		final List<DataRow> fieldDataRowList = new ArrayList<DataRow>();
		File file = new File("files/Input to Upload - Bid File - Pre IRoute, Upload Ready.xls");
		FileInputStream fis = new FileInputStream(file);
		Workbook workbook = WorkbookFactory.create(fis);
		int numberOfSheets = workbook.getNumberOfSheets();
		for (int index = 0; index < numberOfSheets; index++){
			final Sheet sheet = workbook.getSheetAt(index);
			short lastCell = 0;
			for (final Row row : sheet) {
	        	if(lastCell < row.getLastCellNum()) {
	        		lastCell = row.getLastCellNum();
	        	}
	        }
			
			for (final Row row : sheet){
				final List<DataColumn> dataColumns = new ArrayList<DataColumn>();
				final DataRow fieldDataRow = new DataRow();
				for (short count = 0; count < lastCell; count++) {
					final Cell cell = row.getCell(count, Row.CREATE_NULL_AS_BLANK);
					DataColumn dataColumn = new DataColumn();
					final DataFormatter dataFormatter = new DataFormatter();
					// CellReference cellReference = new CellReference(dataCell);
					final String cellValue = dataFormatter.formatCellValue(cell);
	                dataColumn.setColumnValue(cellValue);
	                dataColumns.add(dataColumn);
				}
				fieldDataRow.setDataColumn(dataColumns);
				fieldDataRowList.add(fieldDataRow);
			}
		}
		System.out.println("bb : "+fieldDataRowList);
		System.out.println(objList);
	}
}
