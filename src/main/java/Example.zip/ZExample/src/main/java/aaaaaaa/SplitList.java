package aaaaaaa;

import java.util.ArrayList;
import java.util.List;

public class SplitList
{
    public static void main(String[] args)
    {
        List<Integer> data = new ArrayList<Integer>();
        for(int i = 0; i <= 6; i++) {
            data.add(i);
        }
        int listSize = data.size()/ 10;
        if(data.size() % 10 > 0) {
            listSize = listSize + 1;
        }
        double t = 49700/40000.0;
        System.out.println(t);
        for(int i = 0; i <  listSize ; i++) {
            int frmIndex = i*10;
            int toIndex = (i*10)+10;
            if(toIndex > data.size()) {
                toIndex = data.size();
            }
            System.out.println(data.subList(frmIndex, toIndex));
        }
    }
}
