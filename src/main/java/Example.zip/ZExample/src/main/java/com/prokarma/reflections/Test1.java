package com.prokarma.reflections;

public class Test1
{
    private String numbers = "ssssssssss";

    public String getNumbers()
    {
        return numbers;
    }

    public void setNumber(String number)
    {
        this.numbers = number;
    }
}
