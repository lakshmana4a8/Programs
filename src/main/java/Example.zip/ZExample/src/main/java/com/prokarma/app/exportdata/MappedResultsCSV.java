package com.prokarma.app.exportdata;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64OutputStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.prokarma.app.json.entity.FileData;

public class MappedResultsCSV {

	public static final SimpleDateFormat standard = new SimpleDateFormat("MM/dd/yyyy");
	private static final Logger LOGGER = LogManager
			.getLogger(MappedResultsCSV.class);

	private StringBuilder outputData = new StringBuilder();

	public void exportMappedDataToCSV(final HttpServletResponse response) {
		writeFileDataToBuffer();
		final String fileName = "Sample.csv";
		ExportDataWriter.writeCSV(response, outputData, fileName);

	}

	private void writeFileDataToBuffer() {
		createMetaDataRows();
		createMapRow("Mapped Row");
		createDataRow("Header Row");
		for(int i=0;i<10;i++){
			createDataRow("Data Row");
		}
	}

	public String retrieveExportDataForAttachment(final FileData fileData)
			throws IOException {
		writeFileDataToBuffer();
		final ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		final Base64OutputStream base64Stream = new Base64OutputStream(
				byteStream);
		try {
			base64Stream.write(outputData.toString().getBytes());
		} finally {
			if (base64Stream != null) {
				try {
					base64Stream.close();
				} catch (final Exception e) {
					LOGGER.error(
							"Error occurred while closing Base64OutputStream",
							e);
				}
			}
		}
		final String attachementContent = byteStream.toString("ASCII");
		return attachementContent;
	}

	private void createMetaDataRows()
    {
        createMetaDataRow("User ID", "xprk259");
        createMetaDataRow("Date", getCurrentDataAsString());
        createMetaDataRow("Business Group", "Business Group");
        createMetaDataRow("Business Sub Group", "Business Sub Group");
        createMetaDataRow("Customer Name", "Customer Name");
        createMetaDataRow("Competitor", "Competitor");
        createMetaDataRow("Market Intelligence Type", "Market Intelligence Type");
        createMetaDataRow("Purpose", "Purpose");
        createMetaDataRow("Equipment Type", "Equipment Type");
        createMetaDataRow("Mode", "Mode");
        createMetaDataRow("Commodity", "Commodity");
        createMetaDataRow("Unit Qualifier", "Unit Qualifier");
        createMetaDataRow("Price Qualifier", "Price Qualifier");
    }
	
	private static String getCurrentDataAsString() {
        final Calendar today = Calendar.getInstance();
        return standard.format(today.getTime());
    }

	private void createMetaDataRow(final String lable, final String value) {
		
		outputData.append(lable + "," +StringUtils.defaultString(value, StringUtils.EMPTY));
		
		outputData.append('\n');

	}
	private void createMapRow(String mappedRow) {
		int count = 0;
		for (int i = 0; i<6; i++) {
			outputData.append(StringUtils.defaultString(mappedRow+i));
			if (count != 5) {
				outputData.append(",");
			}
			count++;
		}
		outputData.append('\n');
	}

	private void createDataRow(String row) {
		int count = 0;
		for (int i = 0; i<6; i++) {
			outputData.append(StringUtils.defaultString(row+i));
			if (count != 5) {
				outputData.append(",");
			}
			count++;
		}
		outputData.append('\n');
	}
}