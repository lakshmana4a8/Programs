package loggers;

import java.util.logging.Logger;

public class LoggerExample
{
    static final Logger logger = Logger.getLogger(LoggerExample.class.getName());
    public static void main(String[] args)
    {
        logger.info("ssssssss");
        logger.severe("severe");
        logger.warning("war");
        System.out.println(logger.getName());
        System.out.println(Integer.valueOf(34563+11));
        System.out.println(Integer.MAX_VALUE);
        System.out.println(Integer.SIZE);
    }
}
