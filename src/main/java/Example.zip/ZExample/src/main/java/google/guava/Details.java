package google.guava;

import java.util.List;

public class Details {
	private String gender;
	private int age;
	private List<Adress> adress;
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public List<Adress> getAdress() {
		return adress;
	}
	public void setAdress(List<Adress> adress) {
		this.adress = adress;
	}
	@Override
	public String toString() {
		return "Details [gender=" + gender + ", age=" + age + ", adress="
				+ adress + "]";
	}
}
