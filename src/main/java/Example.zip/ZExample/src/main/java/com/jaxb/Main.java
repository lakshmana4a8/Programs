package com.jaxb;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

public class Main {
	
	@SuppressWarnings("static-access")
	public static void main(String args[]) throws JAXBException, ParserConfigurationException{
		Book book = new Book();
		Address address = new Address();
		List<Book> booksList = new ArrayList<Book>();
		List<Address> addressList = new ArrayList<Address>();
		
		book.setAuthor("author");
		book.setIsbn("isbn");
		book.setName("name");
		book.setPublisher("publisher");
		
		address.setCity("city");
		address.setName("aaaaaaaaaaa");
		
		booksList.add(book);
		addressList.add(address);
		
		BookList bookList = new BookList();
		bookList.setAddressType(addressList);
		bookList.setBookType(booksList);
		bookList.setBookName("bookname");
		
		String value = bookList.marshal(bookList, BookList.class);
		System.out.println(value);
		BookList bookList2 = (BookList) bookList.unmarshal(value, BookList.class);
		System.out.println(bookList2);
	}
}
