package com.prokarma.app.springconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Configuration
public class AppMultipartConfiguration {
	@Bean
    public CommonsMultipartResolver multipartResolver() {
       final CommonsMultipartResolver mr = new CommonsMultipartResolver();           
       return mr;
   }
}
