package main.methods.java;

import java.io.FileOutputStream;
import java.io.IOException;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class FileWriterThroughSXSSF{
public static void main(String[] args) throws IOException {
SXSSFWorkbook wb = new SXSSFWorkbook(10);
Sheet sh = wb.createSheet("FirstSheet");
for (int rownum = 0; rownum < 100; rownum++) {
Row row = sh.createRow(rownum);
for (int cellnum = 0; cellnum < 10; cellnum++) {
Cell cell = row.createCell(cellnum);
String cellValue = "Cell" + cellnum;
cell.setCellValue(cellValue);
}
}
for(int rownum = 0; rownum < 90; rownum++){
         System.out.println(sh.getRow(rownum));
       }
// ther last 100 rows are still in memory
        for(int rownum = 90; rownum < 100; rownum++){
        System.out.println(sh.getRow(rownum));
        }
        
        FileOutputStream out = new FileOutputStream("src/test/resources/Write-XLS-Data-SXSSF3.xlsx");
        wb.write(out);
        out.close();

        // dispose of temporary files backing this workbook on disk
        wb.dispose();

}
}