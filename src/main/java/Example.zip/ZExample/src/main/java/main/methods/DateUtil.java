package main.methods;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateUtil {
	public static final SimpleDateFormat STANDARD_FORMAT = new SimpleDateFormat("MMM/dd/yyyy");
	public static final SimpleDateFormat STANDARD_FORMATSS = new SimpleDateFormat("yyyyMM");
	public static void main(String[] args) throws ParseException {
		Calendar today = Calendar.getInstance();
		System.out.println("Current Date : "+ STANDARD_FORMAT.format(today.getTime()));
		
		today.set(2014,00,01);
		today.add(Calendar.MONTH, -1);
		System.out.println("Previous Month : "+ (today.get(Calendar.MONTH) + 1));
		System.out.println("Current Year : "+ today.get(Calendar.YEAR));
		String dateYear = STANDARD_FORMATSS.format(today.getTime());
		System.out.println("Current Date : "+ dateYear);
		
		today = Calendar.getInstance();
		today.set(2014,00,01);
		today.add(Calendar.MONTH, -12);
		System.out.println("Previous Month : "+ (today.get(Calendar.MONTH) + 1));
		System.out.println("Previous Year : "+today.get(Calendar.YEAR));
		dateYear = STANDARD_FORMATSS.format(today.getTime());
		System.out.println("Current Date : "+ dateYear);
	}
}
