package sample;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetExample
{
    public static void main(String[] args)
    {
        List<String> rampMtpnList1 = new ArrayList<String>();
        rampMtpnList1.add("1");
        rampMtpnList1.add("2");
        rampMtpnList1.add("3");
        rampMtpnList1.add("4");
        List<String> rampSplcList2 = new ArrayList<String>();
        rampSplcList2.add("3");
        rampSplcList2.add("4");
        rampSplcList2.add("5");
        rampSplcList2.add("6");
        final Set<String> rampSPLCList = new HashSet<String>();
        rampSPLCList.addAll(rampMtpnList1);
        rampSPLCList.addAll(rampSplcList2);
        System.out.println(rampSPLCList);
    }
}
