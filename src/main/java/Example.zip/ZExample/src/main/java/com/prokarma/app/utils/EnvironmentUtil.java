package com.prokarma.app.utils;

import org.apache.commons.lang3.ObjectUtils;


public final class EnvironmentUtil
{

    private static final String UPRR_IMPLEMENTATION_ENVIRONMENT_KEY = "uprr.implementation.environment";

    private EnvironmentUtil()
    {
    }

    public static String getEnv()
    {
        final String environment = ObjectUtils.firstNonNull(System.getProperty(UPRR_IMPLEMENTATION_ENVIRONMENT_KEY),
            System.getProperty(UPRR_IMPLEMENTATION_ENVIRONMENT_KEY.toUpperCase()),
            System.getenv().get(UPRR_IMPLEMENTATION_ENVIRONMENT_KEY),
            System.getenv().get(UPRR_IMPLEMENTATION_ENVIRONMENT_KEY.toUpperCase()));

        return environment;
    }

    public static boolean isLocal()
    {
        final String environment = getEnv();
        return "local".equalsIgnoreCase(environment) || "win".equalsIgnoreCase(environment) ||
            "desktop".equalsIgnoreCase(environment);
    }

    public static boolean isDev()
    {
        return "dev".equalsIgnoreCase(getEnv());
    }

    public static boolean isTest()
    {
        return "test".equalsIgnoreCase(getEnv());
    }

    public static boolean isProduction()
    {
        return "prod".equalsIgnoreCase(getEnv());
    }


}
