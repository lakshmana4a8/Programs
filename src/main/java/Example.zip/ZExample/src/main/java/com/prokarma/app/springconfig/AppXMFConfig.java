package com.prokarma.app.springconfig;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;

import org.acegisecurity.providers.ProviderManager;
import org.acegisecurity.providers.dao.DaoAuthenticationProvider;
import org.springframework.aop.target.CommonsPoolTargetSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;

import com.prokarma.app.utils.ClientCredentialProvider;
import com.prokarma.app.utils.EnvironmentUtil;
import com.uprr.app.xmf.RequestHandler;
import com.uprr.app.xmf.StaxMessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.ServiceProxyException;
import com.uprr.app.xmf.client.ServiceProxyFactory;
import com.uprr.app.xmf.client.core.ServiceProxyFactoryImpl;
import com.uprr.app.xmf.client.security.core.CyberArkClientCredentialProvider;
import com.uprr.app.xmf.client.security.core.CyberArkUserDetailsService;
import com.uprr.app.xmf.client.security.core.DefaultSecurityPolicy;
import com.uprr.app.xmf.client.security.core.SecurityHandler;
import com.uprr.app.xmf.client.security.core.SecurityTokenServiceProxy;
import com.uprr.app.xmf.client.security.core.XmfCredentialProvider;

public class AppXMFConfig {
	@Autowired
    private Environment environment;

    @Autowired
    private JndiTemplate jndiTemplate;

    private String xmfConnectionFactory = "xmf.connectionFactory";
    private String esbQueue = "xmf.esbQueue";
    private String xmfClientId = "xmf.clientId";
    private String jmsUserName = "tibco.username";
    private String developerJMSKey = "tibco.key";
    private String developerXMFKey = "xmf.key";

    static final int POOL_MAX_SIZE = 10;
    static final int POOL_MAX_IDLE = 3;
    
    @Bean
    public Destination esbQueue()
    {
        final JndiObjectFactoryBean factoryBean = new JndiObjectFactoryBean();
        factoryBean.setJndiName(environment.getProperty(esbQueue));
        factoryBean.setJndiTemplate(jndiTemplate);
        try
        {
            factoryBean.afterPropertiesSet();
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return (Destination) factoryBean.getObject();
    }

    @Bean
    public ConnectionFactory xmfConnectionFactory()
    {
        final JndiObjectFactoryBean factoryBean = new JndiObjectFactoryBean();
        factoryBean.setJndiName(environment.getProperty(xmfConnectionFactory));
        factoryBean.setJndiTemplate(jndiTemplate);
        try
        {
            factoryBean.afterPropertiesSet();
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return (ConnectionFactory) factoryBean.getObject();
    }

    @Bean
    public ServiceProxyFactoryImpl serviceProxyFactory()
    {
        final ServiceProxyFactoryImpl serviceProxyFactory;
        try
        {
            serviceProxyFactory = new ServiceProxyFactoryImpl(authenticatingConnectionFactory(),
                environment.getProperty(xmfClientId), false);
        }
        catch (final ServiceProxyException e)
        {
            throw new RuntimeException(e);
        }
        return serviceProxyFactory;
    }

    @Bean
    @Scope(value = "prototype")
    public ServiceProxy serviceProxy()
    {

        final ServiceProxyFactory serviceProxyFactory = serviceProxyFactory();

        final ServiceProxy serviceProxy;
        try
        {
            serviceProxy = serviceProxyFactory.createServiceProxy();
        }
        catch (final ServiceProxyException e)
        {
            throw new RuntimeException(e);
        }
        serviceProxy.setRequestDestination(esbQueue());

        final List<RequestHandler> requestHandlerList = new ArrayList<RequestHandler>();
        requestHandlerList.add(securityHandler());
        serviceProxy.setRequestHandlers(requestHandlerList);

        return serviceProxy;
    }

    @Bean
    public UserCredentialsConnectionFactoryAdapter authenticatingConnectionFactory()
    {
        final UserCredentialsConnectionFactoryAdapter authenticationConnectionFactory = new UserCredentialsConnectionFactoryAdapter();
        authenticationConnectionFactory.setTargetConnectionFactory(xmfConnectionFactory());
        authenticationConnectionFactory.setUsername(environment.getProperty(jmsUserName));
        authenticationConnectionFactory.setPassword(retrieveJMSPassword());
        return authenticationConnectionFactory;
    }

    @Bean
    public StaxMessageUtilities messageUtilities()
    {
        return new StaxMessageUtilities();
    }

    @Bean
    public CommonsPoolTargetSource serviceProxyPool()
    {
        final CommonsPoolTargetSource serviceProxyPool = new CommonsPoolTargetSource();
        serviceProxyPool.setTargetBeanName("serviceProxy");
        serviceProxyPool.setMaxSize(POOL_MAX_SIZE);
        serviceProxyPool.setMaxIdle(POOL_MAX_IDLE);
        serviceProxyPool.setWhenExhaustedActionName("WHEN_EXHAUSTED_FAIL");
        serviceProxyPool.setTargetClass(ServiceProxy.class);

        return serviceProxyPool;
    }

    @Bean
    public DefaultSecurityPolicy defaultPolicy()
    {
        final DefaultSecurityPolicy defaultPolicy = new DefaultSecurityPolicy();
        defaultPolicy.setSecurityTokenService(new SecurityTokenServiceProxy());
        return defaultPolicy;
    }

    @Bean
    public SecurityHandler securityHandler()
    {

        final Map<String, DefaultSecurityPolicy> servicePoliciesMap = new HashMap<String, DefaultSecurityPolicy>();
        /** servicePoliciesMap.put("user/is-authorized/1.0", defaultPolicy()); */
        final SecurityHandler securityHandler = new SecurityHandler();
        securityHandler.setServicePolicies(servicePoliciesMap);
        return securityHandler;
    }


    @Bean
    public ProviderManager authenticationManager()
    {
        final List<DaoAuthenticationProvider> daoProviderList = new ArrayList<DaoAuthenticationProvider>();
        daoProviderList.add(daoAuthenticationProvider());
        final ProviderManager providerManager = new ProviderManager();
        providerManager.setProviders(daoProviderList);
        return providerManager;
    }

    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider()
    {
        final DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
        authenticationProvider.setUserDetailsService(userDetailsService());
        authenticationProvider.setHideUserNotFoundExceptions(false);
        return authenticationProvider;
    }

    @Bean
    public CyberArkClientCredentialProvider credentialProvider()
    {
        final CyberArkClientCredentialProvider cyberArkProvider;
        if (EnvironmentUtil.isLocal())
        {
            cyberArkProvider = new ClientCredentialProvider(environment.getProperty(developerXMFKey));
        }
        else
        {
            cyberArkProvider = new CyberArkClientCredentialProvider();
        }
        return cyberArkProvider;
    }

    @Bean
    public CyberArkUserDetailsService userDetailsService()
    {
        final CyberArkUserDetailsService userDetailsService;
        try
        {
            final Constructor<CyberArkUserDetailsService> cyberArkUserDetailsConstructor = CyberArkUserDetailsService.class.getDeclaredConstructor(new Class[] {
                    XmfCredentialProvider.class, String.class, String.class, String.class, String.class});
            cyberArkUserDetailsConstructor.setAccessible(true);
            userDetailsService = cyberArkUserDetailsConstructor.newInstance(new Object[] {credentialProvider(),
                    EnvironmentUtil.getEnv(), "Novell-eDirectory" /*StandardizationConstants.CYBER_ARK_SYSTEM_XMF*/,
                    "App TLA", environment.getProperty(jmsUserName)});

        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return userDetailsService;
    }

    private String retrieveJMSPassword()
    {
        if (EnvironmentUtil.isLocal())
        {
            return environment.getProperty(developerJMSKey);
        }
        return "password";
//        return CyberArkUtil.retrieveJMSPassword(environment.getProperty(jmsUserName));
    }
}
