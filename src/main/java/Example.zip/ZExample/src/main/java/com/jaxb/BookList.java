package com.jaxb;

import java.io.Serializable;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "book-list")
public class BookList implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@XmlElement(name = "book-type", namespace = "", required = true)
    private List<Book>      bookType;
    @XmlElement(name = "address-type", namespace = "", required = true)
    private List<Address>   addressType;
    @XmlElement(name = "book-name", namespace = "", required = true)
    private String bookName;
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public List<Book> getBookType() {
		return bookType;
	}
	public void setBookType(List<Book> bookType) {
		this.bookType = bookType;
	}
	public List<Address> getAddressType() {
		return addressType;
	}
	public void setAddressType(List<Address> addressType) {
		this.addressType = addressType;
	}
	
	public static String marshal(Object requestData, Class<?> classType) throws JAXBException, ParserConfigurationException {
		JAXBContext context = null;
		context = JAXBContext.newInstance(classType);
		Marshaller marshaller = null;
		marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		Document doc = null;
		doc = dbf.newDocumentBuilder().newDocument();
		StringWriter writer = new StringWriter();
		if (doc != null) {
		    marshaller.marshal(requestData, writer);
		    return writer.toString();
		}
		return null;
    }

	public static Object unmarshal(final String replyData,
			final Class<?> classType) {

		Object replyObject = null;
		try {
			final JAXBContext context = JAXBContext.newInstance(classType);

			final InputSource inputSource = new InputSource();
			inputSource.setCharacterStream(new StringReader(replyData));

			final Unmarshaller unmarshal = context.createUnmarshaller();
			replyObject = unmarshal.unmarshal(inputSource);

		} catch (final Exception e) {
			throw new RuntimeException(e);
		}
		return replyObject;
	}
	
	@Override
	public String toString() {
		return "BookList [bookType=" + bookType + ", addressType="
				+ addressType + ", bookName=" + bookName + "]";
	}
}
