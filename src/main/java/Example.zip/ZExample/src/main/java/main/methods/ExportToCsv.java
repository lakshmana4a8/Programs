package main.methods;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.commons.lang3.StringUtils;

public class ExportToCsv {
	private static StringBuilder outputData = new StringBuilder();
	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("WriteTest.csv");
	    PrintWriter out = new PrintWriter(fw);
//	    out.print("This");
//	    out.print(",");
//	    out.print("is");
//	    out.print(",");
//	    out.println("amazing");
//	    out.print("It's");
//	    out.print(",");
//	    out.print("really");
//	    out.print(",");
//	    out.print("amazing");
//	    out.flush();
//	    out.close();
//	    fw.close();
		createDataRows();
		outputData.append('\n');
		createHeaderRow();
		createDataRow("Data Row ");
	    out.print(outputData);
	    out.flush();
	    out.close();
	    fw.close();
	}
	private static void createDataRows() {
		createRow("Row1", "Value1");
		createRow("Row2", "Value2");
		createRow("Row3", "Value3");
		createRow("Row4", "Value4");
	}
	private static void createDataRow(String row) {
		int count = 0;
		for(int j=0;j<10;j++){
			for (int i = 0; i<6; i++) {
				outputData.append(StringUtils.defaultString(row+i));
				if (count != 5) {
					outputData.append(",");
				}
				count++;
			}
		outputData.append('\n');
		}
	}
	private static void createHeaderRow() {
		int count = 0;
		for (int i = 0; i<6; i++) {
			outputData.append(StringUtils.defaultString("Header Row "+i));
			if (count != 5) {
				outputData.append(",");
			}
			count++;
		}
		outputData.append('\n');
	}
	private static void createRow(String lable, String value) {
		outputData.append(lable + "," +StringUtils.defaultString(value, StringUtils.EMPTY));
		outputData.append('\n');
	}
}
