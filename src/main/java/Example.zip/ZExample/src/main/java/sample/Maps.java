package sample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jaxb.Book;

public class Maps
{
    public static void main(String[] args)
    {
        List<Long> list = new ArrayList<Long>();
        list.add(60L);
        list.add(70L);
        list.add(130L);
        list.add(210L);
        list.add(310L);
        list.add(410L);
        list.add(510L);
        Map<String, List<Book>> map = new HashMap<String, List<Book>>();
        for(int i=0; i<=10; i++) {
            map.put("list"+i, new ArrayList<Book>());
        }
        for(Long data : list) {
            if(data >= 0 && data <=120) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list1").add(book);
            }else if(data >= 121 && data <=180) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list2").add(book);
            }else if(data >= 181 && data <=180) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list3").add(book);
            }else if(data >= 241 && data <=240) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list4").add(book);
            }else if(data >= 301 && data <=360) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list5").add(book);
            }else if(data >= 361 && data <=420) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list6").add(book);
            }else if(data >= 421 && data <=480) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list7").add(book);
            }else if(data >= 481 && data <=540) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list8").add(book);
            }else if(data >= 541 && data <=600) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list9").add(book);
            }else if(data >= 601 && data <=660) {
                Book book = new Book();
                book.setName(String.valueOf(data));
                map.get("list10").add(book);
            }
        }
        System.out.println(map);
    }
}
