package com.prokarma.app.utils;

import com.uprr.app.xmf.client.security.core.CyberArkClientCredentialProvider;

public class ClientCredentialProvider extends CyberArkClientCredentialProvider
{

    private String localXmfPassword;

    public ClientCredentialProvider(final String localXmfPassword)
    {
        this.localXmfPassword = localXmfPassword;
    }

    @Override
    public String getCredential(String environment, String system, String tla, String appId)
    {
        return localXmfPassword;
    }


}
