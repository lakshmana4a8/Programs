package main.methods;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;

public class JsonConv
{
    public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
        List<String> data1 = new ArrayList<String>();
        data1.add("name");
        data1.add("name2");
        data1.add("name3");
        String data = mapper.writeValueAsString(data1);
        System.out.println(data);
        System.out.println(JSONArray.toJSONString(data1));
        List<String> list = mapper.readValue(data,List.class);
        System.out.println(list);
    }
}
