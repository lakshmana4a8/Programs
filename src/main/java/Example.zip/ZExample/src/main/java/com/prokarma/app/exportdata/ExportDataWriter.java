package com.prokarma.app.exportdata;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Writes the report to the output stream
 */
public class ExportDataWriter
{

    private static final Logger LOGGER = LogManager.getLogger(ExportDataWriter.class);

    /**
     * Writes the report to the output stream
     */
    public static void writeWorkbook(final HttpServletResponse response, final HSSFWorkbook workbook,
        final String fileName)
    {

        LOGGER.debug("Writing report to the stream");
        try
        {
            response.setHeader("Content-Disposition", "inline; filename=\"" + fileName + "\"");
            // Make sure to set the correct content type
            response.setContentType("application/vnd.ms-excel");
            // Write to the output stream

            // Retrieve the output stream
            ServletOutputStream outputStream = response.getOutputStream();
            response.setCharacterEncoding("UTF-8");
            // Write to the output stream
            workbook.write(outputStream);
            // Flush the stream
            outputStream.flush();

        }
        catch (final Exception e)
        {
            LOGGER.error("Unable to write report to the output stream", e);
        }
    }

    public static void writeCSV(final HttpServletResponse response, final StringBuilder outputData,
        final String fileName)
    {

        LOGGER.debug("Writing outputData to CSV file:File Name is:" + fileName);
        try
        {
            response.setHeader("Content-Disposition", "inline; filename=\"" + fileName + "\"");
            // Make sure to set the correct content type
            response.setContentType("text/csv");
            // Write to the output stream

            // Retrieve the output stream
            ServletOutputStream outputStream = response.getOutputStream();
            response.setCharacterEncoding("UTF-8");
            // Write to the output stream
            // Flush the stream
            outputStream.write(outputData.toString().getBytes());
            outputStream.flush();

        }
        catch (final Exception e)
        {
            LOGGER.error("Unable to write outputStream to CSV file");
        }

    }
}
