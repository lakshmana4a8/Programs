package main.methods.string;

import java.util.HashMap;

public class FirstCharacterOfString
{
    public static void main(String[] args)
    {
        String str= "lakshmanl";
        HashMap<Character, Integer> characterhashtable = new HashMap<Character, Integer>();
        int i, length;
        Character c;
        length = str.length(); // Scan string and build hash table
        for (i = 0; i < length; i++)
        {
            c = str.charAt(i);
            if (characterhashtable.containsKey(c))
            {
                characterhashtable.put(c, characterhashtable.get(c) + 1);
            }
            else
            {
                characterhashtable.put(c, 1);
            }
        }

        for (i = 0; i < length; i++)
        {
            c = str.charAt(i);
            if (characterhashtable.get(c) == 1) {
                System.out.println(c);
                break;
            }
        }
    }
}
