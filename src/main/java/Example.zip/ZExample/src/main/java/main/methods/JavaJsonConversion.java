package main.methods;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;

import com.prokarma.app.json.entity.DataColumn;


public class JavaJsonConversion {
//http://stackoverflow.com/questions/19271065/how-to-convert-jsonarray-to-list-of-object-using-camel-jackson
	public static void main(String[] args) throws ParseException {
		final SimpleDateFormat FULL_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String jsonString;
		List<DataColumn> dataColumnList = new ArrayList<DataColumn>();
		DataColumn dataColumn = new DataColumn();
		dataColumn.setColumnIndex(0);
		dataColumn.setColumnType("string0");
		dataColumn.setColumnValue("zero");
		dataColumn.setDate(FULL_FORMAT.parse("2014-01-02 00:00:00.000Z"));
		dataColumnList.add(dataColumn);
		DataColumn dataColumn1 = new DataColumn();
		dataColumn1.setColumnIndex(1);
		dataColumn1.setColumnType("string1");
		dataColumn1.setColumnValue("one");
		dataColumn1.setDate(FULL_FORMAT.parse("2014-01-03 00:00:00.000Z"));
		dataColumnList.add(dataColumn1);
		DataColumn dataColumn2 = new DataColumn();
		dataColumn2.setColumnIndex(2);
		dataColumn2.setColumnType("string2");
		dataColumn2.setColumnValue("two");
		dataColumn2.setDate(new Date());
		dataColumnList.add(dataColumn2);
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(dataColumn);
			System.out.println(jsonString);
			DataColumn data = mapper.readValue(jsonString, DataColumn.class);
			System.out.println(data.getColumnIndex()+" : "+data.getColumnType()+" : "+data.getColumnValue()+" : "+data.getClass());
			jsonString = mapper.writeValueAsString(dataColumnList);
			System.out.println("111111");
			System.out.println(jsonString);
			System.out.println("222");
			List<DataColumn> dataList = mapper.readValue(jsonString, TypeFactory.defaultInstance().constructCollectionType(List.class, DataColumn.class));
			for(DataColumn dataObj : dataList){
				System.out.println(dataObj.getColumnIndex()+" : "+dataObj.getColumnType()+" : "+dataObj.getColumnValue()+" : "+dataObj.getClass());
				System.out.println(dataObj.getDate());
			}
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
