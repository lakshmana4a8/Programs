package com.jaxb;


public class Address {
	private String aaaaaaaaaaa;
	private String city;
	public String getName() {
		return aaaaaaaaaaa;
	}
	public void setName(String aaaaaaaaaaa) {
		this.aaaaaaaaaaa = aaaaaaaaaaa;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
}
