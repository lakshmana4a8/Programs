package com.prokarma.app.springconfig;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.prokarma.app.utils.DBPoolProperties;

@Configuration
@EnableTransactionManagement
public class AppDBConfig {
	@Autowired
    private Environment environment;
	
	private String jdbcUrl = "db.url";
    private String username = "db.username";
    private String developerKey = "db.key";
    private String driverClass = "db.driverclass";
    private String dbInstance = "db.instance";

    static final int POOL_INITIAL_SIZE = 4;
    static final int POOL_MAX_ACTIVE = 12;
    static final long POOL_VALIDATION_INTERVAL = 6000;
    
    @Bean
    public PoolProperties getPoolProperties()
    {

        if (System.getProperty("os.name").toLowerCase().contains("win"))
        {
            System.setProperty("developer.password", environment.getProperty(developerKey));
        }
        final DBPoolProperties poolProperties = new DBPoolProperties();
        poolProperties.setUsername(environment.getProperty(username));
        poolProperties.setAppTLA("tla");
        poolProperties.setRunEnv("environment");
        poolProperties.setDbInstance(environment.getProperty(dbInstance));
        poolProperties.setDriverClassName(environment.getProperty(driverClass));
        poolProperties.setUrl(environment.getProperty(jdbcUrl));
        poolProperties.setInitialSize(POOL_INITIAL_SIZE);
        poolProperties.setMaxActive(POOL_MAX_ACTIVE);
        poolProperties.setMaxIdle(2);
        poolProperties.setMinIdle(2);
        poolProperties.setValidationQuery("select 1 from dual");
        poolProperties.setTestWhileIdle(true);
        poolProperties.setValidationInterval(POOL_VALIDATION_INTERVAL);
        poolProperties.setAccessToUnderlyingConnectionAllowed(true);

        return poolProperties;
    }

    @Bean
    public DataSource getDataSource()
    {
        return new DataSource(getPoolProperties());
    }

    @Bean
    public PlatformTransactionManager txManager()
    {
        return new DataSourceTransactionManager(getDataSource());
    }
}
