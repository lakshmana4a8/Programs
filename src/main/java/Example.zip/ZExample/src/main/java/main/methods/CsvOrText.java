package main.methods;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.prokarma.app.json.entity.DataColumn;
import com.prokarma.app.json.entity.DataRow;

public class CsvOrText {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
        final List<DataRow> fieldDataRowList = new ArrayList<DataRow>();
        try{
        	BufferedReader br = new BufferedReader(new FileReader("files/Equipments.csv"));
            String sCurrentLine = "";
            while ((sCurrentLine = br.readLine()) != null) {
            	List<DataColumn> dataColumns = new ArrayList<DataColumn>();
            	final DataRow fieldDataRow = new DataRow();
            	String[] data = sCurrentLine.split(",");// "/t" for text file
            	int columnCount = 1;
            	for(String attributeValue : data){
					DataColumn dataColumn = new DataColumn();
					dataColumn.setColumnIndex(columnCount);
					dataColumn.setColumnValue(attributeValue);
					dataColumns.add(dataColumn);
					columnCount++;
				}
            	fieldDataRow.setDataColumn(dataColumns);
            	fieldDataRowList.add(fieldDataRow);
            }
            System.out.println(fieldDataRowList);
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
}
