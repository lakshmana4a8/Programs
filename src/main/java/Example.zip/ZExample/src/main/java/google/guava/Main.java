package google.guava;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;

public class Main {
	public static void main(String[] args) {
		List<Adress> adressesList = new ArrayList<Adress>();
		Adress adress = new Adress();
		adress.setCity("hyd");
		adress.setState("TG");
		adressesList.add(adress);
		List<Adress> adressesList1 = new ArrayList<Adress>();
		Adress adress1 = new Adress();
		adress1.setCity("Vizag");
		adress1.setState("AP");
		adressesList1.add(adress1);
		
		List<Details> detailsList = new ArrayList<Details>();
		Details details = new Details();
		details.setAge(21);
		details.setGender("male");
		details.setAdress(adressesList);
		detailsList.add(details);
		List<Details> detailsList1 = new ArrayList<Details>();
		Details details1 = new Details();
		details1.setAge(21);
		details1.setGender("male");
		details1.setAdress(adressesList1);
		detailsList1.add(details1);
		
		List<Student> studentsList = new ArrayList<Student>();
		Student student = new Student();
		student.setId("1");
		student.setName("lakshmna");
		student.setDetails(detailsList);
		Student student1 = new Student();
		student1.setId("2");
		student1.setName("ram");
		student1.setDetails(detailsList1);
		studentsList.add(student);
		studentsList.add(student1);
		
		FluentIterable<FluentIterable<Adress>> ss = FluentIterable.from(studentsList).
		transform(new Function<Student, FluentIterable<Adress>>() {
			public FluentIterable<Adress> apply(Student s) {
				return 
				FluentIterable.from(s.getDetails()).
				transform(new Function<Details, Adress>() {
					public Adress apply(Details d) {
						return (Adress) d.getAdress();
					}
				});
			}
		});
		for(FluentIterable<Adress> sa : ss) {
			System.out.println(sa);
		}
		
	}
}
