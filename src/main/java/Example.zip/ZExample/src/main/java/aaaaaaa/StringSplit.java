package aaaaaaa;

import org.apache.commons.lang3.StringUtils;

public class StringSplit
{
    public static void main(String[] args)
    {
        String name  = "L1 pep si 1234";
        String name1 = "L1 pep si co 1234";
        String name2 = "L1 pep si co name 1234";
        System.out.println(name.substring((name.indexOf(" ")+1), name.lastIndexOf(" ")));
        System.out.println(name1.substring((name1.indexOf(" ")+1), name1.lastIndexOf(" ")));
        System.out.println(name2.substring((name2.indexOf(" ")+1), name2.lastIndexOf(" ")));
        
        System.out.println(StringUtils.substring(name,(name.indexOf(" ")+1), name.lastIndexOf(" ")));
    }
}
