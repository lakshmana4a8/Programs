package com.prokarma.app.utils;


/*import com.uprr.app.iae.cyberark.client.CyberArkClient;
import com.uprr.app.iae.cyberark.client.dto.CyberArkPasswordRequestDTO;
import com.uprr.app.iae.cyberark.client.dto.CyberArkPasswordResponseDTO;
import com.uprr.naf.standardization.constants.StandardizationConstants;*/

public final class CyberArkUtil
{
    /*private static final Logger LOGGER = LogManager.getLogger(CyberArkUtil.class);

    private CyberArkUtil()
    {
    }

    public static String retrieveJMSPassword(final String applicationUserId)
    {
        final String jmsPassword = retrievePassword(applicationUserId, StandardizationConstants.CYBER_ARK_SYSTEM_JMS,
            StandardizationConstants.CYBER_ARK_SYSTEM_JMS);
        return jmsPassword;
    }

    public static String retrieveOraclePassword(final String applicationUserId, final String dbInstance)
    {
        final String jmsPassword = retrievePassword(applicationUserId, StandardizationConstants.CYBER_ARK_SYSTEM_ORACLE,
            dbInstance);
        return jmsPassword;
    }

    private static String retrievePassword(final String applicationUserId, final String system, final String resource)
    {
        final CyberArkPasswordRequestDTO cyberArkPasswordRequestDTO = new CyberArkPasswordRequestDTO();
        cyberArkPasswordRequestDTO.setEnvironment(EnvironmentUtil.getEnv());
        cyberArkPasswordRequestDTO.setSystem(system);
        cyberArkPasswordRequestDTO.setTla(StandardizationConstants.APPLICATION_TLA);
        cyberArkPasswordRequestDTO.setApplicationId(applicationUserId);
        cyberArkPasswordRequestDTO.setResource(resource);

        final CyberArkClient cyberArkClient = new CyberArkClient();
        final CyberArkPasswordResponseDTO passwordDetails = cyberArkClient.getPassword(cyberArkPasswordRequestDTO);

        final String password = passwordDetails.getPassword();
        if (StringUtils.isBlank(password))
        {
            LOGGER.error("Received Null password from CyberArk for " + system);
        }
        return password;
    }*/

}
