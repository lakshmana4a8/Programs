package aaaaaaa;

import java.util.ArrayList;
import java.util.List;

public class Sample
{
    public static void main(String[] args) {
        SingleTonObject.getInstance();
        int n = 5;
        for(int i=0;i<n;i++) {
            for(int j=0;j<n-i;j++) {
                System.out.print(" ");
            }
           for(int k=0;k<=i;k++) {
               System.out.print("$ ");
           }
           System.out.println();  
       }

   }
}

class FindDuplicteNumber
{
    public static void main(String[] args) {
        int nuber = 50;
        List<Integer> integers = new ArrayList<Integer>();
        for(int i=1; i<=nuber; i++) {
            integers.add(i);
        }
        integers.add(25);
        integers.add(20);
        integers.add(35);
        List<Integer> dupIntegers = new ArrayList<Integer>();
        for(int i=1; i<integers.size(); i++) {
            if(dupIntegers.contains(integers.get(i))) {
                System.out.println("duplicates : "+integers.get(i));
            }else {
                dupIntegers.add(integers.get(i));
            }
        }
    }
}