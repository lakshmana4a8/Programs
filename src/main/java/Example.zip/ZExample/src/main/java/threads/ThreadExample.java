package threads;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ThreadExample
{
    public static void main (String args[])
    {
//        AnnotationConfigApplicationContext annotationConfigContext = null;
        try
        {
//            annotationConfigContext = new AnnotationConfigApplicationContext(StandardizationConfiguration.class);
        final ScheduledExecutorService scheduleExecutor = Executors.newScheduledThreadPool(5);
        final ThreadShutDown shutdownHook = new ThreadShutDown(scheduleExecutor);
        Runtime.getRuntime().addShutdownHook(shutdownHook);
        final ThreadExample standaloneApp = new ThreadExample();
        final Runnable runnable = new Runnable()
        {
            @Override
            public void run()
            {
                standaloneApp.startStandardization(Thread.currentThread().getId());
            }
        };

        for (int i = 0; i < 5; i++)
        {
            scheduleExecutor.scheduleAtFixedRate(runnable, 0, 1, TimeUnit.SECONDS);
        }
//        scheduleExecutor.shutdown();
        }
        catch (final Exception e)
        {
            /*if (annotationConfigContext != null)
            {
                annotationConfigContext.close();
            }*/
        }
     }

    protected void startStandardization(long l)
    {
        int n= 1;
        int sum=0;
        int nexthundred=n+100;
        while(nexthundred > n)
        sum = sum+(nexthundred--);
        System.out.println("Sum of next hundred numbers is " + sum+" : "+l);
        Thread.currentThread().interrupt();
    }
}
