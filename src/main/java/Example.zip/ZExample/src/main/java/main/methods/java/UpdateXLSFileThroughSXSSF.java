package main.methods.java;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UpdateXLSFileThroughSXSSF {

	public static void main(String[] args) throws InvalidFormatException,
			IOException {
		
		File excelFile = new File("src/test/resources/Write-XLS-Data-SXSSF3.xlsx");

	    InputStream inp = new FileInputStream(excelFile);
//	    Workbook workbook = new XSSFWorkbook(inp);
//	    inp.close();
	    /*XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0);
	    for (int rownum = 101; rownum < 110; rownum++) {
	    	XSSFRow row = sheet.createRow(rownum);
			for (int cellnum = 0; cellnum < 10; cellnum++) {
				XSSFCell cell = row.createCell(cellnum);
				String cellValue = "Extra Cell" + cellnum;
				cell.setCellValue(cellValue);
			}
	    }
	    FileOutputStream fileOut = new FileOutputStream(excelFile);
	    workbook.write(fileOut);
	    fileOut.close();*/
	    
		@SuppressWarnings("static-access")
		Workbook workbook = new WorkbookFactory().create(inp);
		inp.close();
		SXSSFWorkbook swb = new SXSSFWorkbook((XSSFWorkbook) workbook, 10,
				false);
		SXSSFSheet sheet1 = (SXSSFSheet) swb.getSheet("FirstSheet");
		for (int rownum = 101; rownum < 110; rownum++) {
			SXSSFRow row = (SXSSFRow) sheet1.createRow(rownum);
			for (int cellnum = 0; cellnum < 10; cellnum++) {
				SXSSFCell cell = (SXSSFCell) row.createCell(cellnum);
				String cellValue = "Extra" + cellnum;
				cell.setCellValue(cellValue);
			}
		}

		for (int rownum = 101; rownum < 110; rownum++) {
			System.out.println(sheet1.getRow(rownum).getCell(1));
		}

		FileOutputStream fileOutputStream = new FileOutputStream(excelFile);

//		swb.createSheet("FirstSheet1");
		swb.write(fileOutputStream);
		fileOutputStream.close();

		// dispose of temporary files backing this workbook on disk
		swb.dispose();
	}

}