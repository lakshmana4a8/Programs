package com.prokarma.app.json.entity;

import java.util.List;

public class DataRow {
	private int rowIndex;
    private List<DataColumn> dataColumn;

    public DataRow()
    {
    }

    public int getRowIndex()
    {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex)
    {
        this.rowIndex = rowIndex;
    }

    public List<DataColumn> getDataColumn()
    {
        return dataColumn;
    }

    public void setDataColumn(List<DataColumn> dataColumn)
    {
        this.dataColumn = dataColumn;
    }

    @Override
    public String toString()
    {
        return dataColumn.toString();
    }
}
