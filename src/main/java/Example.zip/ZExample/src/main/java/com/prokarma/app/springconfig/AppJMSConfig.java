package com.prokarma.app.springconfig;

import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;

import com.prokarma.app.utils.EnvironmentUtil;

@Configuration
public class AppJMSConfig {
	@Autowired
    private Environment environment;

    private String jmsConnectionFactory = "jms.intial.connection.factory";
    private String tibcoUrl = "tibco.url";
    private String tibcoUserName = "tibco.username";
    private String developerJMSKey = "tibco.key";
    private String enaConnectionFactory = "ena.connectionFactory";
    private String enaQueue = "ena.queue";

    @Bean
    public JndiTemplate jndiTemplate()
    {
        final JndiTemplate jndiTemplate = new JndiTemplate();
        final Properties properties = new Properties();
        properties.setProperty("java.naming.factory.initial", environment.getProperty(jmsConnectionFactory));
        properties.setProperty("java.naming.provider.url", environment.getProperty(tibcoUrl));
        properties.setProperty("java.naming.security.principal", environment.getProperty(tibcoUserName));
        properties.setProperty("java.naming.security.credentials", retrieveJMSPassword());
        jndiTemplate.setEnvironment(properties);
        return jndiTemplate;
    }

    private String retrieveJMSPassword()
    {
        if (EnvironmentUtil.isLocal())
        {
            return environment.getProperty(developerJMSKey);
        }
//        return CyberArkUtil.retrieveJMSPassword(environment.getProperty(tibcoUserName));
		return "password";
    }
    
    @Bean
    public ConnectionFactory connectionFactory()
    {
        final JndiObjectFactoryBean factoryBean = new JndiObjectFactoryBean();
        factoryBean.setJndiName(environment.getProperty(enaConnectionFactory));
        factoryBean.setJndiTemplate(jndiTemplate());
        try
        {
            factoryBean.afterPropertiesSet();
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return (ConnectionFactory) factoryBean.getObject();

    }

    @Bean
    public Destination enaNotificationQueue()
    {
        final JndiObjectFactoryBean factoryBean = new JndiObjectFactoryBean();
        factoryBean.setJndiName(environment.getProperty(enaQueue));
        factoryBean.setJndiTemplate(jndiTemplate());
        try
        {
            factoryBean.afterPropertiesSet();
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return (Destination) factoryBean.getObject();
    }

    @Bean
    public UserCredentialsConnectionFactoryAdapter enaQueueConnectionFactory()
    {
        final UserCredentialsConnectionFactoryAdapter factoryBean = new UserCredentialsConnectionFactoryAdapter();
        factoryBean.setUsername(environment.getProperty(tibcoUserName));
        factoryBean.setPassword(retrieveJMSPassword());
        factoryBean.setTargetConnectionFactory(connectionFactory());
        return factoryBean;
    }

    @Bean
    public JmsTemplate enaJmsTemplate()
    {
        final JmsTemplate factoryBean = new JmsTemplate();
        factoryBean.setConnectionFactory(enaQueueConnectionFactory());
        factoryBean.setDefaultDestination(enaNotificationQueue());
        return factoryBean;
    }
}
