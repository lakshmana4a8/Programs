package com.prokarma.app.json.entity;

public class Customer
{


    private String name;
    private String fullName;
    private String firmNumber;
    private String cifNumber;
    private String cifSuffix;
    private String lookupData;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getFullName()
    {
        return fullName;
    }

    public void setFullName(String fullName)
    {
        this.fullName = fullName;
    }

    public String getFirmNumber()
    {
        return firmNumber;
    }

    public void setFirmNumber(String firmNumber)
    {
        this.firmNumber = firmNumber;
    }

    public String getCifSuffix()
    {
        return cifSuffix;
    }

    public void setCifSuffix(String cifSuffix)
    {
        this.cifSuffix = cifSuffix;
    }

    public String getCifNumber()
    {
        return cifNumber;
    }

    public void setCifNumber(String cifNumber)
    {
        this.cifNumber = cifNumber;
    }

    public String getLookupData()
    {
        this.lookupData = this.name + " " + this.firmNumber + " " + this.cifNumber + " " + this.cifSuffix;
        return lookupData;
    }

    public void setLookupData(String lookupData)
    {
        this.lookupData = lookupData;
    }

    @Override
    public String toString()
    {
        return "Customer [name=" + name + ", fullName=" + fullName + ", firmNumber=" + firmNumber + ", cifNumber=" +
            cifNumber + "]";
    }


}
