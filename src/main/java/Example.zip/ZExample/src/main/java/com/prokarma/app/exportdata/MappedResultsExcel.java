package com.prokarma.app.exportdata;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFPrintSetup;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;

public class MappedResultsExcel {
	private HSSFWorkbook workbook = null;
	private HSSFSheet sheet = null;
	private HSSFFont boldFont = null;
	private HSSFFont normalFont = null;
	public static final SimpleDateFormat standard = new SimpleDateFormat("MM/dd/yyyy");

	int rowNbr = 0;

	public MappedResultsExcel() {
		// create Work Book
		workbook = new HSSFWorkbook();
		// create the common cell styles
	}

	private void createWorkBookSheet(final String sheetTitle) {
		rowNbr = 0;
		sheet = workbook.createSheet(sheetTitle);
		sheet.setDefaultColumnWidth(15);
		// resultsSheet.setColumnWidth(0, 5500);
		// set the print settings for the work sheet
		final HSSFPrintSetup print = sheet.getPrintSetup();
		print.setLandscape(true);
	}

	public void exportMappedDataToExcel(final HttpServletResponse response) {
		writeFileDataToWorkbook();
		final String fileName = "Sample.xls";
		ExportDataWriter.writeWorkbook(response, workbook, fileName);
	}

	private void writeFileDataToWorkbook() {
		createWorkBookSheet("Sheet");
		createMetaDataRows();
		++rowNbr;
		createMapRow("Mapped Row");

		createDataRow("Header Row", true);
		for (int i = 0; i < 10; i++) {
			createDataRow("Table Data Row", false);
		}
	}

	private void createMetaDataRows() {
		createMetaDataRow("User ID", "xprk259");
		createMetaDataRow("Date", getCurrentDataAsString());
		createMetaDataRow("Business Group", "Business Group");
		createMetaDataRow("Business Sub Group", "Business Sub Group");
		createMetaDataRow("Customer Name", "Customer Name");
		createMetaDataRow("Competitor", "Competitor");
		createMetaDataRow("Market Intelligence Type",
				"Market Intelligence Type");
		createMetaDataRow("Purpose", "Purpose");
		createMetaDataRow("Equipment Type", "Equipment Type");
		createMetaDataRow("Mode", "Mode");
		createMetaDataRow("Commodity", "Commodity");
		createMetaDataRow("Unit Qualifier", "Unit Qualifier");
		createMetaDataRow("Price Qualifier", "Price Qualifier");
	}

	private static String getCurrentDataAsString() {
		final Calendar today = Calendar.getInstance();
		return standard.format(today.getTime());
	}

	private void createMetaDataRow(final String label, final String value) {
		final int rowNum = ++rowNbr;
		final HSSFCellStyle headerStyle = getColumnHeaderStyle((short) 0);
		final HSSFCellStyle columnStyle = getColumnStyle((short) 0);
		final HSSFRow metaDataRow = sheet.createRow(rowNum);

		final HSSFCell labelCell = metaDataRow.createCell(0);
		labelCell.setCellValue(new HSSFRichTextString(label));
		labelCell.setCellStyle(headerStyle);

		final HSSFCell valueCell = metaDataRow.createCell(1);
		valueCell.setCellValue(new HSSFRichTextString(value));
		valueCell.setCellStyle(columnStyle);
	}

	private void createMapRow(String mappedRow) {
		final int rowNum = ++rowNbr;
		final HSSFCellStyle columnStyle = getColumnHeaderStyle((short) 0);
		final HSSFRow mappingRow = sheet.createRow(rowNum);
		int cellNbr = 0;
		for (int i = 0; i < 6; i++) {
			final HSSFCell mappingCell = mappingRow.createCell(cellNbr);
			mappingCell.setCellValue(new HSSFRichTextString(mappedRow + i));
			mappingCell.setCellStyle(columnStyle);
			cellNbr++;
		}
	}

	private void createDataRow(String dataRow, final boolean headerRow) {
		final int rowNum = ++rowNbr;
		HSSFCellStyle columnStyle = getColumnStyle((short) 0);
		if (headerRow) {
			columnStyle = getColumnHeaderStyle((short) 0);
		}

		final HSSFRow row = sheet.createRow(rowNum);
		int cellNbr = 0;
		for (int i = 0; i < 6; i++) {
			final HSSFCell dataCell = row.createCell(cellNbr);
			dataCell.setCellValue(new HSSFRichTextString(dataRow + i));
			dataCell.setCellStyle(columnStyle);
			cellNbr++;
		}
	}

	private HSSFCellStyle getColumnStyle(final short formatIndex) {
		final HSSFCellStyle columnStyle = workbook.createCellStyle();
		columnStyle.setAlignment(CellStyle.ALIGN_LEFT);
		columnStyle.setBorderLeft((short) 1);
		columnStyle.setBorderRight((short) 1);
		columnStyle.setBorderTop((short) 1);
		columnStyle.setBorderBottom((short) 1);
		columnStyle.setDataFormat(formatIndex);
		columnStyle.setFont(getFont());
		columnStyle.setWrapText(true);
		return columnStyle;
	}

	private HSSFCellStyle getColumnHeaderStyle(final short formatIndex) {
		final HSSFCellStyle columnHeaderStyle = workbook.createCellStyle();
		columnHeaderStyle.setFillBackgroundColor(getUPHeaderColor());
		columnHeaderStyle.setAlignment(CellStyle.ALIGN_LEFT);
		columnHeaderStyle.setFillForegroundColor(getUPHeaderColor());
		columnHeaderStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		columnHeaderStyle.setBorderLeft((short) 1);
		columnHeaderStyle.setBorderRight((short) 1);
		columnHeaderStyle.setBorderTop((short) 1);
		columnHeaderStyle.setBorderBottom((short) 1);
		columnHeaderStyle.setDataFormat(formatIndex);
		columnHeaderStyle.setFont(getBoldFont());
		columnHeaderStyle.setWrapText(true);
		columnHeaderStyle.setVerticalAlignment((short) 0);
		return columnHeaderStyle;
	}

	private HSSFFont getBoldFont() {
		if (boldFont == null) {
			boldFont = workbook.createFont();
			boldFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			boldFont.setFontHeightInPoints((short) 8);
		}
		return boldFont;
	}

	private HSSFFont getFont() {
		if (normalFont == null) {
			normalFont = workbook.createFont();
			normalFont.setFontHeightInPoints((short) 8);
		}
		return normalFont;
	}

	private short getUPHeaderColor() {
		final HSSFPalette palette = workbook.getCustomPalette();

		final byte redValue = (byte) 236;
		final byte greenValue = (byte) 172;
		final byte blueValue = (byte) 0;

		// choose a seed color index
		final short colorIndex = HSSFColor.RED.index + 1;
		palette.setColorAtIndex(colorIndex, redValue, greenValue, blueValue);
		return colorIndex;
	}

	@SuppressWarnings("unused")
	private short getUPBodyColor() {
		final HSSFPalette palette = workbook.getCustomPalette();

		final byte redValue = (byte) 145;
		final byte greenValue = (byte) 0;
		final byte blueValue = (byte) 0;

		// choose a seed color index
		final short colorIndex = HSSFColor.RED.index + 1;
		palette.setColorAtIndex(colorIndex, redValue, greenValue, blueValue);
		return colorIndex;
	}

}
