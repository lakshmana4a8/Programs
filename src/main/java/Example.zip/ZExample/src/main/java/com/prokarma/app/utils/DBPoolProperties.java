package com.prokarma.app.utils;

import java.net.UnknownHostException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.tomcat.jdbc.pool.PoolProperties;

public class DBPoolProperties extends PoolProperties {
	private String dbInstance;
    private String appTLA;
    private String runEnv;
    private static String hostName;

    public void setDbInstance(String dbInstance)
    {
        this.dbInstance = dbInstance;
    }

    public void setAppTLA(String appTLA)
    {
        this.appTLA = appTLA;
    }


    public void setRunEnv(String runEnv)
    {
        this.runEnv = runEnv;
    }


    public String getDbInstance()
    {
        return dbInstance;
    }


    public String getAppTLA()
    {
        return appTLA;
    }


    public String getRunEnv()
    {
        return runEnv;
    }


    public void setHostName(String hostName)
    {
        DBPoolProperties.hostName = hostName;
    }


    public String getHostName()
    {
        return DBPoolProperties.hostName;
    }


    @Override
    public String getPassword()
    {
        return getApplicationPassword();
    }

    @Override
    public boolean isJmxEnabled()
    {
        return false;
    }

    @Override
    public boolean isPoolSweeperEnabled()
    {
        return true;
    }

    @Override
    public String getPoolName()
    {
        return this.getAppTLA() + "_" + this.getRunEnv() + "_JBBC_POOL_" + hostName;
    }

    @Override
    public void setName(String name)
    {
        final String poolName = this.getAppTLA() + "_" + this.getRunEnv() + "_JBBC_POOL_" + hostName;
        super.setName(poolName);
    }

    private static final Logger LOGGER = LogManager.getLogger(DBPoolProperties.class);

    static
    {
        try
        {
            hostName = java.net.InetAddress.getLocalHost().getHostName();
            LOGGER.info(" Host name: " + hostName);
        }
        catch (final UnknownHostException e)
        {
            LOGGER.error("Error getting host name: " + e);
        }
    }


    private String getApplicationPassword()
    {

        if (System.getProperty("os.name").toLowerCase().contains("win"))
        {
            return System.getProperty("developer.password");
        }
        // get password from cyber ark utils
        return "password";

    }
}
