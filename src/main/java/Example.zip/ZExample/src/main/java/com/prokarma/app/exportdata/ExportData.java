package com.prokarma.app.exportdata;

import javax.servlet.http.HttpServletResponse;

public interface ExportData {
	void exportDataToExcel(HttpServletResponse response);

	void exportDataToCsv(HttpServletResponse response);
}
