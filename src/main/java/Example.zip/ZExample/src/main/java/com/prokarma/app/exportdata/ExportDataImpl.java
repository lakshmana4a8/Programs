package com.prokarma.app.exportdata;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

@Service
public class ExportDataImpl implements ExportData{

	@Override
	public void exportDataToExcel(final HttpServletResponse response) {
		System.out.println("exportDataToExcel");
		final MappedResultsExcel mappedResultsExcel = new MappedResultsExcel();
		mappedResultsExcel.exportMappedDataToExcel(response);
	}
	
	@Override
	public void exportDataToCsv(final HttpServletResponse response) {
		System.out.println("exportDataToCsv");
		final MappedResultsCSV mappedResultsCSV = new MappedResultsCSV();
		mappedResultsCSV.exportMappedDataToCSV(response);
	}
}
