package com.prokarma.app.customerservice;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.prokarma.app.json.entity.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	public List<Customer> findCustomers(String inputValue) {
		System.out.println("service");
		if(StringUtils.isEmpty(inputValue)){
			return new ArrayList<Customer>();
		}
		List<Customer> customers = new ArrayList<Customer>();
		Customer customer = new Customer();
		customer.setFullName("lakshmna");
		customers.add(customer);
		return customers;
	}

	@Override
	public String getStringVal(String val) {
		return "lakshman ";
	}
}
