package com.prokarma.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.prokarma.app.customerservice.CustomerService;
import com.prokarma.app.json.entity.Customer;

@Controller
@RequestMapping()
public class UserController {
	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
    public @ResponseBody String testInfo() {
        return customerService.getStringVal("chs");
    }
	@RequestMapping(value = "/xmf", method = RequestMethod.GET)
	public @ResponseBody
	List<Customer> customerInfo() {
		System.out.println("in controller");
		List<Customer> customers = customerService.findCustomers("CHS");
		return customers;
	}
	@RequestMapping(value = "/getUser", method = RequestMethod.GET)
	public @ResponseBody
	String getUser() {
		System.out.println("in controller");
		return "lakshmna";
	}

}
