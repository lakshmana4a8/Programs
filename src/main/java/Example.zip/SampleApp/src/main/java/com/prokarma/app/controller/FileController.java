package com.prokarma.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.prokarma.app.json.entity.Customer;

@Controller
@RequestMapping()
public class FileController {
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
    public @ResponseBody
    ResponseEntity<List<Customer>> handleFileUpload(@RequestParam("file") final MultipartFile file) {
        final List<Customer> response = new ArrayList<Customer>(1);
        final ResponseEntity<List<Customer>> successResponse = new ResponseEntity<List<Customer>>(response, HttpStatus.OK);
        return successResponse;
    }
	
	@RequestMapping(value = "/db", method = RequestMethod.GET)
    public @ResponseBody
    ResponseEntity<Integer> checkDBConnection() {
        final ResponseEntity<Integer> successResponse = new ResponseEntity<Integer>(2, HttpStatus.OK);
        return successResponse;
    }
}