'use strict';

var AngularSpringApp = {};

var App = angular.module('AngularSpringApp', ['ngRoute' , 'ui.bootstrap','angularFileUpload']);

App.config(['$routeProvider', function ($routeProvider) {
    
    $routeProvider.when('/about', {
        templateUrl: 'html/about.html',
        controller: 'aboutCtrl'
    });
    
    $routeProvider.otherwise({redirectTo: '/about'});
}]);
App.controller('indexCtrl',function($scope,$http){
	console.log('indexCtrl');
});
App.controller('aboutCtrl',function($scope,$http,$upload){
	$scope.selectedFiles = [];
	$scope.resetInputFile = function() {
		$scope.selectedFiles = [];
		var elems = document.getElementsByTagName('input');
		for (var i = 0; i < elems.length; i++) {
			if (elems[i].type === 'file') {
				elems[i].value = null;
			}
		}
	};
	$scope.onFilesSelect = function($files) {
		$scope.selectedFiles = [];
		$scope.selectedFiles = $files;
		$scope.tableRowData = [];
		$scope.tableHeaders = [];
		$scope.list = [];
	};
	$scope.uploadFiles = function() {
		$upload.upload({
			url : '/spring-services/application/upload',
			method : 'POST',
			headers : {
				'Content-Type' : 'multipart/form-data'
			},
			file : $scope.selectedFiles[0],
			fileFormDataName : 'file'
		}).success(function(data) {
			angular.forEach(data,function(listOfObjs){
				$scope.tableHeaders = [];
				$scope.tableRowData = [];
				angular.forEach(listOfObjs.fieldData,function(objsData){
					$scope.tableHeaders = listOfObjs.fieldData[0].dataColumn;
					var localData = [];
					angular.forEach(objsData.dataColumn,function(aaaaaaaa){
						localData.push(aaaaaaaa);
					});
					$scope.tableRowData.push(localData);
				});
				$scope.list.push({'tableHeaders' : $scope.tableHeaders, 'tableRowData' : $scope.tableRowData});
			});
		}).error(function(data, status) {
			console.log(data, status);
		});
	};
	$http({
		method : "GET",
		headers : {
			'Cache-Control' : 'no-cache',
			'Pragma': 'no-cache'						
		},
		url : "/spring-services/application/getUser"
	}).success(function(data) {
		$scope.lll = data;
	}).error(function(data, status) {
		console.log(data);
	});
	/*$scope.tabs = [
	               { title:'Dynamic Title 1', content:'html/about.html' },
	               { title:'Dynamic Title 2', content:'Dynamic content 2', disabled: true }
	             ];*/
});
/*App.controller('indexCtrl',function($scope,$http){
	console.log('indexCtrl');
});
App.controller('aboutCtrl',function($scope,$http,$upload){
	$scope.selectedFiles = [];
	$scope.resetInputFile = function() {
		$scope.selectedFiles = [];
		var elems = document.getElementsByTagName('input');
		for (var i = 0; i < elems.length; i++) {
			if (elems[i].type === 'file') {
				elems[i].value = null;
			}
		}
	};
	$scope.onFilesSelect = function($files) {
		$scope.selectedFiles = [];
		$scope.selectedFiles = $files;
	};
	$scope.tableRowData = [];
	$scope.uploadFiles = function() {
		$upload.upload({
			url : '/spring-services/application/upload',
			method : 'POST',
			headers : {
				'Content-Type' : 'multipart/form-data'
			},
			file : $scope.selectedFiles[0],
			fileFormDataName : 'file'
		}).success(function(data) {
			$scope.tableHeaders = data[0].dataColumn;
			angular.forEach(data,function(dataObj){
				var localData = [];
				angular.forEach(dataObj.dataColumn,function(aaaaaaaa){
					localData.push(aaaaaaaa);
				});
				$scope.tableRowData.push(localData);
			});
		}).error(function(data, status) {
			console.log(data, status);
		});
	};
	$http({
		method : "GET",
		headers : {
			'Cache-Control' : 'no-cache',
			'Pragma': 'no-cache'						
		},
		url : "/spring-services/application/getUser"
	}).success(function(data) {
		$scope.lll = data;
	}).error(function(data, status) {
		console.log(data);
	});
});*/