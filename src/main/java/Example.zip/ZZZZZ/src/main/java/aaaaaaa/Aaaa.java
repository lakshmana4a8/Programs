package aaaaaaa;

public class Aaaa
{
    public static void main(String[] args)
    {
        System.out.println(23>024);
        int c=0,a,temp;  
        int n=153;//It is the number to check armstrong  
        temp=n;  
        while(n>0)  
        {  
        a=n%10;  
        System.out.println("aaaaaa : "+a);   
        n=n/10; 
        System.out.println("nnnnnnnnn : "+n);   
        c=c+(a*a*a);  
        System.out.println("ccccccccc : "+c);   
        }  
        if(temp==c)  
            System.out.println("armstrong number");   
        else  
            System.out.println("Not armstrong number");   
    }
}
