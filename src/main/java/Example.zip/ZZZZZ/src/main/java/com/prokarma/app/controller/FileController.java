package com.prokarma.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.prokarma.app.db.FileUploadDBService;
import com.prokarma.app.file.FileUploadService;
import com.prokarma.app.json.entity.DataRow;

@Controller
@RequestMapping()
public class FileController {
	@Autowired
	private FileUploadService fileUploadService;
	@Autowired
	private FileUploadDBService fileUploadDBService;
	
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
    public @ResponseBody
    ResponseEntity<List<DataRow>> handleFileUpload(@RequestParam("file") final MultipartFile file) {
        final List<DataRow> response = fileUploadService.handleFileUpload(file);
        final ResponseEntity<List<DataRow>> successResponse = new ResponseEntity<List<DataRow>>(response, HttpStatus.OK);
        return successResponse;
    }
	
	@RequestMapping(value = "/db", method = RequestMethod.GET)
    public @ResponseBody
    ResponseEntity<Integer> checkDBConnection() {
		int length = fileUploadDBService.checkDBConnection();
        final ResponseEntity<Integer> successResponse = new ResponseEntity<Integer>(length, HttpStatus.OK);
        return successResponse;
    }
	
	@RequestMapping(value = "/standardize", method = RequestMethod.GET)
	public @ResponseBody
	ResponseEntity<String> standardize() {
		fileUploadDBService.standardize();
		final ResponseEntity<String> successResponse = new ResponseEntity<String>("Success", HttpStatus.OK);
		return successResponse;
	}
}