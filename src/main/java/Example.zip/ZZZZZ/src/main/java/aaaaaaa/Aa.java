package aaaaaaa;

public class Aa
{
    public static void main(String[] args)
    {
        int sum = 0;
        for (int i = 0, j = 0; i < 6 & j < 6; ++i, j = i + 1)
        {
            System.out.println(i+" : "+j);
            sum += i;
            System.out.println(sum);
        }
    }
}
