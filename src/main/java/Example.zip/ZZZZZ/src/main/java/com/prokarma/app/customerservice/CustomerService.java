package com.prokarma.app.customerservice;

import java.util.List;

import com.prokarma.app.json.entity.Customer;

public interface CustomerService {
	List<Customer> findCustomers(final String inputValue);
	String getStringVal(final String val);
}
