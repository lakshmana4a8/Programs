package com.prokarma.app.db;

public interface FileUploadDBService {

	int checkDBConnection();

	void standardize();

}
