package excel;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.eventusermodel.EventWorkbookBuilder.SheetRecordCollectingListener;
import org.apache.poi.hssf.eventusermodel.FormatTrackingHSSFListener;
import org.apache.poi.hssf.eventusermodel.HSSFEventFactory;
import org.apache.poi.hssf.eventusermodel.HSSFListener;
import org.apache.poi.hssf.eventusermodel.HSSFRequest;
import org.apache.poi.hssf.eventusermodel.MissingRecordAwareHSSFListener;
import org.apache.poi.hssf.eventusermodel.dummyrecord.LastCellOfRowDummyRecord;
import org.apache.poi.hssf.eventusermodel.dummyrecord.MissingCellDummyRecord;
import org.apache.poi.hssf.model.HSSFFormulaParser;
import org.apache.poi.hssf.record.BOFRecord;
import org.apache.poi.hssf.record.BlankRecord;
import org.apache.poi.hssf.record.BoolErrRecord;
import org.apache.poi.hssf.record.BoundSheetRecord;
import org.apache.poi.hssf.record.FormulaRecord;
import org.apache.poi.hssf.record.LabelRecord;
import org.apache.poi.hssf.record.LabelSSTRecord;
import org.apache.poi.hssf.record.NoteRecord;
import org.apache.poi.hssf.record.NumberRecord;
import org.apache.poi.hssf.record.RKRecord;
import org.apache.poi.hssf.record.Record;
import org.apache.poi.hssf.record.SSTRecord;
import org.apache.poi.hssf.record.StringRecord;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class XLS2CSVmra implements HSSFListener {

	private POIFSFileSystem fs;

	private boolean outputFormulaValues = true;

	private SheetRecordCollectingListener workbookBuildingListener;
	private HSSFWorkbook stubWorkbook;

	private SSTRecord sstRecord;
	private FormatTrackingHSSFListener formatListener;

	private int sheetIndex = -1;
	private BoundSheetRecord[] orderedBSRs;
	private List<BoundSheetRecord> boundSheetRecords = new ArrayList<BoundSheetRecord>();

	private boolean outputNextStringRecord;
	Map<String, Map<String, List<String>>> fieldDataModelList = new HashMap<String, Map<String, List<String>>>();
	private Map<String, List<String>> fieldDataList = new HashMap<String, List<String>>();

	public XLS2CSVmra(POIFSFileSystem fs, int minColumns) {
		this.fs = fs;
	}

	public XLS2CSVmra(String filename, int minColumns) throws IOException, FileNotFoundException {
		this(new POIFSFileSystem(new FileInputStream(filename)), minColumns);
	}

	public Map<String, Map<String, List<String>>> process() throws IOException {
		MissingRecordAwareHSSFListener listener = new MissingRecordAwareHSSFListener(this);
		formatListener = new FormatTrackingHSSFListener(listener);
		HSSFEventFactory factory = new HSSFEventFactory();
		HSSFRequest request = new HSSFRequest();
		if (outputFormulaValues) {
			request.addListenerForAllRecords(formatListener);
		} else {
			workbookBuildingListener = new SheetRecordCollectingListener(
					formatListener);
			request.addListenerForAllRecords(workbookBuildingListener);
		}
		factory.processWorkbookEvents(request, fs);
		return fieldDataModelList;
	}

	List<String> dataList = new ArrayList<String>();
	String sheetNAme = "";
	String dupSheetNAme = "";
	int kk = 0;
	int ab = -1;
	int row = -1;
	public void processRecord(Record record) {
		String thisStr = null;
		switch (record.getSid()) {
		case BoundSheetRecord.sid:
			boundSheetRecords.add((BoundSheetRecord) record);
			break;
		case BOFRecord.sid:
			BOFRecord br = (BOFRecord) record;
			if (br.getType() == BOFRecord.TYPE_WORKSHEET) {
				if (workbookBuildingListener != null && stubWorkbook == null) {
					stubWorkbook = workbookBuildingListener
							.getStubHSSFWorkbook();
				}
				if(ab == sheetIndex) {
					kk = 0;
				}
				sheetIndex++;
				ab = sheetIndex;
				if (orderedBSRs == null) {
					orderedBSRs = BoundSheetRecord
							.orderByBofPosition(boundSheetRecords);
				}
				fieldDataModelList.put(orderedBSRs[sheetIndex].getSheetname(),fieldDataList);
				fieldDataList = new HashMap<String, List<String>>();
				sheetNAme = orderedBSRs[sheetIndex].getSheetname();
				dupSheetNAme = orderedBSRs[sheetIndex].getSheetname();
				// fieldDataList = new HashMap<String, List<String>>();
				// output.println(orderedBSRs[sheetIndex].getSheetname() + " ["
				// + (sheetIndex + 1) + "]:");
			}
			break;
		case SSTRecord.sid:
			sstRecord = (SSTRecord) record;
			break;
		case BlankRecord.sid:
			thisStr = "";
			break;
		case BoolErrRecord.sid:
			thisStr = "";
			break;
		case FormulaRecord.sid:
			FormulaRecord frec = (FormulaRecord) record;
			if (outputFormulaValues) {
				if (Double.isNaN(frec.getValue())) {
					outputNextStringRecord = true;
				} else {
					thisStr = formatListener.formatNumberDateCell(frec);
				}
			} else {
				thisStr = '"' + HSSFFormulaParser.toFormulaString(stubWorkbook,
						frec.getParsedExpression()) + '"';
			}
			break;
		case StringRecord.sid:
			if (outputNextStringRecord) {
				StringRecord srec = (StringRecord) record;
				thisStr = srec.getString();
				outputNextStringRecord = false;
			}
			break;
		case LabelRecord.sid:
			LabelRecord lrec = (LabelRecord) record;
			thisStr = '"' + lrec.getValue() + '"';
			break;
		case LabelSSTRecord.sid:
			LabelSSTRecord lsrec = (LabelSSTRecord) record;
			if (sstRecord == null) {
				thisStr = '"' + "(No SST Record, can't identify string)" + '"';
			} else {
				thisStr = '"' + sstRecord.getString(lsrec.getSSTIndex())
						.toString() + '"';
			}
			break;
		case NoteRecord.sid:
			thisStr = '"' + "(TODO)" + '"';
			break;
		case NumberRecord.sid:
			NumberRecord numrec = (NumberRecord) record;
			thisStr = formatListener.formatNumberDateCell(numrec);
			break;
		case RKRecord.sid:
			thisStr = '"' + "(TODO)" + '"';
			break;
		default:
			break;
		}
		
		if(record.getSid() == -1) {
			row++;
		}
		if (record instanceof MissingCellDummyRecord) {
			thisStr = "";
		}
		if (thisStr != null) {
			dataList.add(thisStr);
		}
		if (record instanceof LastCellOfRowDummyRecord) {
			System.out.println("sheetNAme : "+sheetNAme);
			String ac = dupSheetNAme;
			if(ac.equalsIgnoreCase(sheetNAme)) {
				
			}
//			System.out.println("record.getSid() : "+record.getSid()+":"+sheetIndex);
			fieldDataList.put(String.valueOf(kk), dataList);
			dataList = new ArrayList<String>();
			kk++;
		}
	}

	public static void main(String[] args) throws Exception {
		int minColumns = -1;
		if (args.length >= 2) {
			minColumns = Integer.parseInt(args[1]);
		}
		XLS2CSVmra xls2csv = new XLS2CSVmra("Y:/NAFD/ZZZZZ/files/NAFD Test file33.xls", minColumns);
		Map<String, Map<String, List<String>>> fieldDataModelList = xls2csv.process();
		System.out.println(fieldDataModelList);
	}
}
