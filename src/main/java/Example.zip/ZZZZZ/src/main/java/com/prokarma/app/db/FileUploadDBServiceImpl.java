package com.prokarma.app.db;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prokarma.app.dao.FileUploadDBDao;

@Service
public class FileUploadDBServiceImpl implements FileUploadDBService{
	
	@Autowired
	private FileUploadDBDao fileUploadDBDao;
	
	@Override
	public int checkDBConnection() {
		System.out.println("Service checkDBConnection()");
		return fileUploadDBDao.checkDBConnection();
	}

	@Override
	public void standardize() {
		System.out.println("Service standardize()");
		fileUploadDBDao.standardize();
	}

}
