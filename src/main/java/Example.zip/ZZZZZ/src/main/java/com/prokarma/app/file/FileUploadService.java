package com.prokarma.app.file;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.prokarma.app.json.entity.DataRow;

public interface FileUploadService {
	List<DataRow> handleFileUpload(final MultipartFile file);
}
