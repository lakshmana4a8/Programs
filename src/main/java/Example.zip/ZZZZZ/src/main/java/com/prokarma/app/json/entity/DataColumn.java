package com.prokarma.app.json.entity;

public class DataColumn {
	private int columnIndex;
    private String columnValue;
    private String columnType;

    public DataColumn()
    {
    }

    public int getColumnIndex()
    {
        return columnIndex;
    }

    public void setColumnIndex(int columnIndex)
    {
        this.columnIndex = columnIndex;
    }

    public String getColumnValue()
    {
        return columnValue;
    }

    public void setColumnValue(String columnValue)
    {
        this.columnValue = columnValue;
    }

    public String getColumnType()
    {
        return columnType;
    }

    public void setColumnType(String columnType)
    {
        this.columnType = columnType;
    }

    @Override
    public String toString()
    {
        return columnValue ;
    }
}
