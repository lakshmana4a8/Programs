package com.prokarma.app.dao.marketintelligencefile;

import java.util.Date;

public class MarketIntelligenceMasterVO
{

    private Long marketIntelligenceId;
    private String entryType;
    private Long marketIntelligenceFileId;
    private String customerName;
    private String firmNbr;
    private String cifAlphaCode;
    private String cifSuffix;
    private String purposeDesc;
    private String businessGroupName;
    private String businessSubGroupName;
    private String commodityDesc;
    private String stccCode;
    private String marketIntelligencyType;
    private String fileName;
    private String sheetName;
    private String fileType;
    private Integer headerRowNbr;
    private Long fileSizeValu;
    private String lastStateCode;
    private String currentProcessingCode;
    private Date lastSavedDate;
    private String competitor;
    private String modeType;
    private String equipmentType;
    private String priceQualifier;
    private String unitQualifier;
    private Long fieldMappingDataId;
    private String sourceColumnName;
    private String targetColumnName;
    private Integer sourceColumnNbr;

    public Long getMarketIntelligenceId()
    {
        return marketIntelligenceId;
    }

    public void setMarketIntelligenceId(final Long marketIntelligenceId)
    {
        this.marketIntelligenceId = marketIntelligenceId;
    }

    public String getEntryType()
    {
        return entryType;
    }

    public void setEntryType(final String entryType)
    {
        this.entryType = entryType;
    }

    public Long getMarketIntelligenceFileId()
    {
        return marketIntelligenceFileId;
    }

    public void setMarketIntelligenceFileId(final Long marketIntelligenceFileId)
    {
        this.marketIntelligenceFileId = marketIntelligenceFileId;
    }

    public String getCustomerName()
    {
        return customerName;
    }

    public void setCustomerName(final String customerName)
    {
        this.customerName = customerName;
    }

    public String getFirmNbr()
    {
        return firmNbr;
    }

    public void setFirmNbr(final String firmNbr)
    {
        this.firmNbr = firmNbr;
    }


    public String getCifAlphaCode()
    {
        return cifAlphaCode;
    }

    public void setCifAlphaCode(final String cifAlphaCode)
    {
        this.cifAlphaCode = cifAlphaCode;
    }

    public String getCifSuffix()
    {
        return cifSuffix;
    }

    public void setCifSuffix(final String cifSuffix)
    {
        this.cifSuffix = cifSuffix;
    }

    public String getPurposeDesc()
    {
        return purposeDesc;
    }

    public void setPurposeDesc(final String purposeDesc)
    {
        this.purposeDesc = purposeDesc;
    }

    public String getBusinessGroupName()
    {
        return businessGroupName;
    }

    public void setBusinessGroupName(final String businessGroupName)
    {
        this.businessGroupName = businessGroupName;
    }

    public String getBusinessSubGroupName()
    {
        return businessSubGroupName;
    }

    public void setBusinessSubGroupName(final String businessSubGroupName)
    {
        this.businessSubGroupName = businessSubGroupName;
    }

    public String getCommodityDesc()
    {
        return commodityDesc;
    }

    public void setCommodityDesc(final String commodityDesc)
    {
        this.commodityDesc = commodityDesc;
    }

    public String getStccCode()
    {
        return stccCode;
    }

    public void setStccCode(final String stccCode)
    {
        this.stccCode = stccCode;
    }

    public String getMarketIntelligencyType()
    {
        return marketIntelligencyType;
    }

    public void setMarketIntelligencyType(final String marketIntelligencyType)
    {
        this.marketIntelligencyType = marketIntelligencyType;
    }

    public String getFileName()
    {
        return fileName;
    }

    public void setFileName(final String fileName)
    {
        this.fileName = fileName;
    }

    public String getSheetName()
    {
        return sheetName;
    }

    public void setSheetName(final String sheetName)
    {
        this.sheetName = sheetName;
    }

    public String getFileType()
    {
        return fileType;
    }

    public void setFileType(final String fileType)
    {
        this.fileType = fileType;
    }


    public Integer getHeaderRowNbr()
    {
        return headerRowNbr;
    }

    public void setHeaderRowNbr(final Integer headerRowNbr)
    {
        this.headerRowNbr = headerRowNbr;
    }

    public Long getFileSizeValu()
    {
        return fileSizeValu;
    }

    public void setFileSizeValu(final Long fileSizeValu)
    {
        this.fileSizeValu = fileSizeValu;
    }

    public String getLastStateCode()
    {
        return lastStateCode;
    }

    public void setLastStateCode(final String lastStateCode)
    {
        this.lastStateCode = lastStateCode;
    }

    public Date getLastSavedDate()
    {
        return lastSavedDate;
    }

    public void setLastSavedDate(final Date lastSavedDate)
    {
        this.lastSavedDate = lastSavedDate;
    }

    public Long getFieldMappingDataId()
    {
        return fieldMappingDataId;
    }

    public void setFieldMappingDataId(final Long fieldMappingDataId)
    {
        this.fieldMappingDataId = fieldMappingDataId;
    }

    public String getSourceColumnName()
    {
        return sourceColumnName;
    }

    public void setSourceColumnName(final String sourceColumnName)
    {
        this.sourceColumnName = sourceColumnName;
    }

    public String getTargetColumnName()
    {
        return targetColumnName;
    }

    public void setTargetColumnName(final String targetColumnName)
    {
        this.targetColumnName = targetColumnName;
    }

    public Integer getSourceColumnNbr()
    {
        return sourceColumnNbr;
    }

    public void setSourceColumnNbr(final Integer sourceColumnNbr)
    {
        this.sourceColumnNbr = sourceColumnNbr;
    }

    public String getCurrentProcessingCode()
    {
        return currentProcessingCode;
    }

    public void setCurrentProcessingCode(final String currentProcessingCode)
    {
        this.currentProcessingCode = currentProcessingCode;
    }

    public String getCompetitor()
    {
        return competitor;
    }

    public void setCompetitor(final String competitor)
    {
        this.competitor = competitor;
    }

    public String getModeType()
    {
        return modeType;
    }

    public void setModeType(final String modeType)
    {
        this.modeType = modeType;
    }

    public String getEquipmentType()
    {
        return equipmentType;
    }

    public void setEquipmentType(final String equipmentType)
    {
        this.equipmentType = equipmentType;
    }

    public String getPriceQualifier()
    {
        return priceQualifier;
    }

    public void setPriceQualifier(final String priceQualifier)
    {
        this.priceQualifier = priceQualifier;
    }

    public String getUnitQualifier()
    {
        return unitQualifier;
    }

    public void setUnitQualifier(final String unitQualifier)
    {
        this.unitQualifier = unitQualifier;
    }


}
