package com.prokarma.app.utils;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.uprr.app.iae.cyberark.client.CyberArkClient;
import com.uprr.app.iae.cyberark.client.dto.CyberArkPasswordRequestDTO;
import com.uprr.app.iae.cyberark.client.dto.CyberArkPasswordResponseDTO;

public class CyberArkUtil {
    private static final Logger LOGGER = LogManager.getLogger(CyberArkUtil.class);

    public static String retrieveJMSPassword(final String applicationUserId)
    {
        final String jmsPassword = retrievePassword(applicationUserId, "JMS", "JMS");
        return jmsPassword;
    }

    public static String retrieveOraclePassword(final String applicationUserId, final String dbInstance)
    {
        final String jmsPassword = retrievePassword(applicationUserId, "Oracle",
            dbInstance);
        return jmsPassword;
    }

    private static String retrievePassword(final String applicationUserId, final String system, final String resource)
    {
        final CyberArkPasswordRequestDTO cyberArkPasswordRequestDTO = new CyberArkPasswordRequestDTO();
        cyberArkPasswordRequestDTO.setEnvironment(getEnv());
        cyberArkPasswordRequestDTO.setSystem(system);
        cyberArkPasswordRequestDTO.setTla("NAF");
        cyberArkPasswordRequestDTO.setApplicationId(applicationUserId);
        cyberArkPasswordRequestDTO.setResource(resource);

        final CyberArkClient cyberArkClient = new CyberArkClient();
        final CyberArkPasswordResponseDTO passwordDetails = cyberArkClient.getPassword(cyberArkPasswordRequestDTO);

        final String password = passwordDetails.getPassword();
        if (StringUtils.isBlank(password))
        {
            LOGGER.error("Received Null password from CyberArk for " + system);
        }
        LOGGER.info("Received Null password from CyberArk for " + password);
        return password;
    }
    private static final String UPRR_IMPLEMENTATION_ENVIRONMENT_KEY = "uprr.implementation.environment";
    public static String getEnv()
    {
        final String environment = ObjectUtils.firstNonNull(System.getProperty(UPRR_IMPLEMENTATION_ENVIRONMENT_KEY),
            System.getProperty(UPRR_IMPLEMENTATION_ENVIRONMENT_KEY.toUpperCase()),
            System.getenv().get(UPRR_IMPLEMENTATION_ENVIRONMENT_KEY),
            System.getenv().get(UPRR_IMPLEMENTATION_ENVIRONMENT_KEY.toUpperCase()));

        return environment;
    }

}
