package com.prokarma.app.utils;

import java.net.UnknownHostException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.tomcat.jdbc.pool.PoolProperties;

public class AppPoolProperties extends PoolProperties {

    private String dbInstance;
    private String appTLA;
    private String runEnv;
    private static String hostName;

    public void setDbInstance(String dbInstance)
    {
        this.dbInstance = dbInstance;
    }

    public void setAppTLA(String appTLA)
    {
        this.appTLA = appTLA;
    }


    public void setRunEnv(String runEnv)
    {
        this.runEnv = runEnv;
    }


    public String getDbInstance()
    {
        return dbInstance;
    }


    public String getAppTLA()
    {
        return appTLA;
    }


    public String getRunEnv()
    {
        return runEnv;
    }


    public void setHostName(String hostName)
    {
        AppPoolProperties.hostName = hostName;
    }


    public String getHostName()
    {
        return AppPoolProperties.hostName;
    }


    @Override
    public String getPassword()
    {
        return getApplicationPassword();
    }

    @Override
    public boolean isJmxEnabled()
    {
        return false;
    }

    @Override
    public boolean isPoolSweeperEnabled()
    {
        return true;
    }

    @Override
    public String getPoolName()
    {
        String poolName = this.getAppTLA() + "_" + this.getRunEnv() + "_JBBC_POOL_" + hostName;
        return poolName;
    }

    @Override
    public void setName(String name)
    {
        String poolName = this.getAppTLA() + "_" + this.getRunEnv() + "_JBBC_POOL_" + hostName;
        super.setName(poolName);
    }

    private static final Logger LOGGER = LogManager.getLogger(AppPoolProperties.class);

    static
    {
        try
        {
            hostName = java.net.InetAddress.getLocalHost().getHostName();
            LOGGER.info(" Host name: " + hostName);
        }
        catch (UnknownHostException e)
        {
            LOGGER.error("Error getting host name: " + e);
        }
    }


    private final String getApplicationPassword()
    {

        if (System.getProperty("os.name").toLowerCase().contains("win"))
        {
            return System.getProperty("developer.password");
        }
        return CyberArkUtil.retrieveOraclePassword(getUsername(), dbInstance);

    }
}