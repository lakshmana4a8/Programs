package com.prokarma.app.dao;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.jdbc.core.simple.ParameterizedBeanPropertyRowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.ReflectionUtils;

import com.prokarma.app.dao.fielddata.FieldDataModel;
import com.prokarma.app.dao.marketintelligencefile.MarketIntelligenceFileModel;
import com.prokarma.app.dao.procque.ProcQueModel;

@Repository
public class FileUploadDBDaoImpl extends NamedParameterJdbcDaoSupport  implements FileUploadDBDao{
	@Autowired
    public void setDS(final DataSource ds){
        setDataSource(ds);
    }

	@Override
	public int checkDBConnection() {
		System.out.println("Dao checkDBConnection()");
		List<MarketIntelligenceFileModel> aaa = getNamedParameterJdbcTemplate().query("select * from NAF_MKT_INTL",
	            ParameterizedBeanPropertyRowMapper.newInstance(MarketIntelligenceFileModel.class));
		return aaa.size();
	}

	@Override
	public void standardize() {
		System.out.println("Dao standardize()");
		List<ProcQueModel> procQueModel = new ArrayList<ProcQueModel>();
		List<FieldDataModel> dataModelsList =getNamedParameterJdbcTemplate().query("select FLD_DATA_ID as fieldDataId from NAF_FLD_DATA where MKT_INTL_SHT_ID=763",
	            ParameterizedBeanPropertyRowMapper.newInstance(FieldDataModel.class));
		for(FieldDataModel dataModel:dataModelsList){
			ProcQueModel queModel = new ProcQueModel();
			queModel.setProcessIndicator(2);
			queModel.setProcessJobTypeCode("Parse");
			queModel.setProcessKeyed1Text(dataModel.getFieldDataId().toString());
			queModel.setProcessKeyed2Text("763");
			queModel.setProcessObjectId("NAF_FLD_DATA");
			procQueModel.add(queModel);
		}
		final SqlParameterSource[] params = SqlParameterSourceUtils.createBatch(procQueModel.toArray());
		final Object initSQL = getValueFromStaticField(ProcQueModel.class, "fullInsertSQL");
		int[] rowsUpdated = getNamedParameterJdbcTemplate().batchUpdate(initSQL.toString(), params);
		System.out.println(rowsUpdated.length);
	}
	
	/*public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		List<ProcQueModel> procQueModel = new ArrayList<ProcQueModel>();
		Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(
				"jdbc:oracle:thin:@dev354.oracle.uprr.com:1521:dev354","dnaf100","g");
			String selectTableSQL = "select FLD_DATA_ID as fieldDataId from NAF_FLD_DATA where MKT_INTL_SHT_ID=763";
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(selectTableSQL);
			List<Long> list = new ArrayList<Long>();
			while (rs.next()) {
				list.add((long) rs.getInt(1));
			}
			for(Long long1:list){
				ProcQueModel queModel = new ProcQueModel();
				queModel.setProcessQueueId(1);
				queModel.setProcessKeyed1text(long1.toString());
				queModel.setProcessKeyed2text("763");
				queModel.setProcessJobTypeCode("Parse");
				queModel.setProcessIndicator(2);
				queModel.setProcessObjectId("NAF_FLD_DATA");
				procQueModel.add(queModel);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}*/

	@SuppressWarnings("rawtypes")
	public Object getValueFromStaticField(final Class object,
			final String methodName) {
		final Field field = ReflectionUtils.findField(object, methodName);
		try {
			return ReflectionUtils.getField(field, object);
		}

		catch (final IllegalArgumentException e) {
			throw new IllegalArgumentException(e);
		}

	}
}
