package com.prokarma.app.utils;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.xml.sax.InputSource;

public class JAXBUtil
{

    public JAXBUtil()
    {
        super();
    }

    public static String marshal(final Object requestData, final Class<?> classType)
    {
        String xmlString = null;
        try
        {
            final JAXBContext context = JAXBContext.newInstance(classType);

            final Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);

            final StringWriter writer = new StringWriter();

            marshaller.marshal(requestData, writer);
            xmlString = writer.toString();
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return xmlString;
    }

    public static Object unmarshal(final String replyData, final Class<?> classType)
    {

        Object replyObject = null;
        try
        {
            final JAXBContext context = JAXBContext.newInstance(classType);

            final InputSource inputSource = new InputSource();
            inputSource.setCharacterStream(new StringReader(replyData));

            final Unmarshaller unmarshal = context.createUnmarshaller();
            replyObject = unmarshal.unmarshal(inputSource);

        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return replyObject;
    }
}
