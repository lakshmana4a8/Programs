package com.prokarma.app.dao;

public interface FileUploadDBDao {

	int checkDBConnection();

	void standardize();

}
