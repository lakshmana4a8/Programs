package com.prokarma.app.utils;

import com.uprr.app.xmf.client.security.core.CyberArkClientCredentialProvider;

public class LocalClientCredentialProvider  extends CyberArkClientCredentialProvider
{

    private String localXmfPassword;

    public LocalClientCredentialProvider(final String localXmfPassword)
    {
        this.localXmfPassword = localXmfPassword;
    }

    @Override
    public String getCredential(String environment, String system, String tla, String appId) throws Exception
    {
        return localXmfPassword;
    }


}
