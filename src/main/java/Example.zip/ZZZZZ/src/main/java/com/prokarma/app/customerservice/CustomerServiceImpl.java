package com.prokarma.app.customerservice;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.prokarma.app.jaxb.customer.CustomerType;
import com.prokarma.app.jaxb.customer.FindCustomerReply;
import com.prokarma.app.jaxb.customer.FindCustomerRequest;
import com.prokarma.app.jaxb.customer.FindCustomerRequest.SearchCriteria;
import com.prokarma.app.jaxb.customer.FindCustomerRequest.SearchCriteria.PartialData;
import com.prokarma.app.json.entity.Customer;
import com.prokarma.app.utils.JAXBUtil;
import com.prokarma.app.xmfservice.XmfService;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	private static final Logger LOGGER = LogManager.getLogger(CustomerServiceImpl.class);
	
	@Autowired
	private XmfService xmfService;

	public List<Customer> findCustomers(String inputValue) {
		System.out.println("service");
		if(StringUtils.isEmpty(inputValue)){
			return new ArrayList<Customer>();
		}
		final String requestXML = getRequestXMLUsingPartialName(inputValue);
		final String responseXML = xmfService.sendXmfRequest("customer/find-customer/2.0", requestXML);
		final FindCustomerReply findCustomerReply = (FindCustomerReply) JAXBUtil.unmarshal(responseXML,
                FindCustomerReply.class);
		final List<Customer> customerListOutput = getCustomersList(findCustomerReply.getCustomers().getCustomer());
		LOGGER.info("findCustomers: End method:, response In = " + customerListOutput);
		return customerListOutput;
	}
	
	private List<Customer> getCustomersList(final List<CustomerType> customerTypeList) {
        final List<Customer> customerList = new ArrayList<Customer>();
        if (!CollectionUtils.isEmpty(customerTypeList)) {
            for (final CustomerType customerType : customerTypeList) {
                if (customerType != null) {
                    final Customer customer = new Customer();
                    customer.setName(customerType.getName());
                    customer.setFullName(customerType.getFullName());
                    if (org.apache.commons.lang3.StringUtils.isNotBlank(customerType.getFirmNumber())) {
                        customer.setFirmNumber(customerType.getFirmNumber());
                    }
                    if (customerType.getCIFNumber() != null) {
                        customer.setCifNumber(customerType.getCIFNumber().getDUNSNumber());
                        customer.setCifSuffix(customerType.getCIFNumber().getDUNSSuffix());
                    }
                    customerList.add(customer);
                }

            }
        }

        return customerList;
    }
	
	private String getRequestXMLUsingPartialName(final String inputValue) {

        final PartialData partialData = new PartialData();
        partialData.setName(inputValue);

        final SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setPartialData(partialData);

        final FindCustomerRequest findCustomerRequest = new FindCustomerRequest();
        findCustomerRequest.setSearchCriteria(searchCriteria);

        final String requestBodyString = JAXBUtil.marshal(findCustomerRequest, FindCustomerRequest.class);
        return requestBodyString;

    }

	@Override
	public String getStringVal(String val) {
		return xmfService.getStringVal(val);
	}
}
