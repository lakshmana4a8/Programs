package com.prokarma.app.dao.marketintelligencefile;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MarketIntelligenceFileModel
{

    public static final Integer COMPLEX_PRIMARY_KEY = 0;
    public static final String PRIMARY_KEY_COLUMN_PARAMETER = "marketintelligencefileid";
    public static final String ROWMAPPER_CLASS_NAME = "com.uprr.app.naf.dao.marketintelligencefile.MarketIntelligenceFileRowMapper";
    /**
     * MKT_INTL_FILE_ID 0 NUMBER
     **/
    private Long marketintelligencefileid;


    /**
     * BUS_GRP_NAME null VARCHAR2
     **/
    private String businessGroupName;


    /**
     * BUS_SUB_GRP_NAME null VARCHAR2
     **/
    private String businesssubgroupname;


    /**
     * CIF_NBR 0 NUMBER
     **/
    private String cifAlphaCode;

    private String cifSuffix;


    /**
     * CMDY_DESC null VARCHAR2
     **/
    private String commodityDescription;


    /**
     * CRTN_DT null DATE
     **/
    private Date creationdate;


    /**
     * CRTN_USER_ID null VARCHAR2
     **/
    private String creationUserId;


    /**
     * CUR_PROC_CODE null VARCHAR2
     **/
    private String currentProcessCode;


    /**
     * CUST_NAME null VARCHAR2
     **/
    private String customerName;


    /**
     * FILE_NAME null VARCHAR2
     **/
    private String fileName;


    /**
     * FILE_SIZE_VALU 0 NUMBER
     **/
    private Long fileSizeValue;


    /**
     * FILE_TYPE null VARCHAR2
     **/
    private String fileType;


    /**
     * FIRM_NBR null VARCHAR2
     **/
    private String firmNumber;


    /**
     * HDR_ROW_NBR 0 NUMBER
     **/
    private Integer headerRowNumber;


    /**
     * LAST_SAVD_DT null DATE
     **/
    private Date lastsaveddate;


    /**
     * LAST_STAT_CODE null VARCHAR2
     **/
    private String lastStatusCode;


    /**
     * LAST_UPTD_DT null DATE
     **/
    private Date lastupdateddate;


    /**
     * LAST_UPTD_USER_ID null VARCHAR2
     **/
    private String lastUpdatedUserId;


    /**
     * MKT_INTL_ID 0 NUMBER
     **/
    private Long marketintelligenceid;


    /**
     * MKT_INTL_TYPE null VARCHAR2
     **/
    private String marketintelligencetype;


    /**
     * PURP_DESC null VARCHAR2
     **/
    private String purposeDescription;


    /**
     * SHT_NAME null VARCHAR2
     **/
    private String sheetName;


    /**
     * STCC_CODE null VARCHAR2
     **/
    private String stccCode;

    private String competitor;
    private String modeType;
    private String equipmentType;
    private String priceQualifier;
    private String unitQualifier;


    public Long getMarketintelligencefileid()
    {
        return this.marketintelligencefileid;
    }

    public void setMarketintelligencefileid(final Long inmarketintelligencefileid)
    {
        this.marketintelligencefileid = inmarketintelligencefileid;
    }

    public String getBusinessGroupName()
    {
        return this.businessGroupName;
    }

    public void setBusinessGroupName(final String inbusinessGroupName)
    {
        this.businessGroupName = inbusinessGroupName;
    }

    public String getBusinesssubgroupname()
    {
        return this.businesssubgroupname;
    }

    public void setBusinesssubgroupname(final String inbusinesssubgroupname)
    {
        this.businesssubgroupname = inbusinesssubgroupname;
    }


    public String getCifAlphaCode()
    {
        return cifAlphaCode;
    }

    public void setCifAlphaCode(final String cifAlphaCode)
    {
        this.cifAlphaCode = cifAlphaCode;
    }

    public String getCifSuffix()
    {
        return cifSuffix;
    }

    public void setCifSuffix(final String cifSuffix)
    {
        this.cifSuffix = cifSuffix;
    }

    public String getCommodityDescription()
    {
        return this.commodityDescription;
    }

    public void setCommodityDescription(final String incommodityDescription)
    {
        this.commodityDescription = incommodityDescription;
    }

    public Date getCreationdate()
    {
        return this.creationdate;
    }

    public void setCreationdate(final Date increationdate)
    {
        this.creationdate = increationdate;
    }

    public String getCreationUserId()
    {
        return this.creationUserId;
    }

    public void setCreationUserId(final String increationUserId)
    {
        this.creationUserId = increationUserId;
    }

    public String getCurrentProcessCode()
    {
        return this.currentProcessCode;
    }

    public void setCurrentProcessCode(final String incurrentProcessCode)
    {
        this.currentProcessCode = incurrentProcessCode;
    }

    public String getCustomerName()
    {
        return this.customerName;
    }

    public void setCustomerName(final String incustomerName)
    {
        this.customerName = incustomerName;
    }

    public String getFileName()
    {
        return this.fileName;
    }

    public void setFileName(final String infileName)
    {
        this.fileName = infileName;
    }

    public Long getFileSizeValue()
    {
        return fileSizeValue;
    }

    public void setFileSizeValue(final Long fileSizeValue)
    {
        this.fileSizeValue = fileSizeValue;
    }

    public String getFileType()
    {
        return this.fileType;
    }

    public void setFileType(final String infileType)
    {
        this.fileType = infileType;
    }

    public String getFirmNumber()
    {
        return this.firmNumber;
    }

    public void setFirmNumber(final String infirmNumber)
    {
        this.firmNumber = infirmNumber;
    }

    public Integer getHeaderRowNumber()
    {
        return this.headerRowNumber;
    }

    public void setHeaderRowNumber(final Integer inheaderRowNumber)
    {
        this.headerRowNumber = inheaderRowNumber;
    }

    public Date getLastsaveddate()
    {
        return this.lastsaveddate;
    }

    public void setLastsaveddate(final Date inlastsaveddate)
    {
        this.lastsaveddate = inlastsaveddate;
    }

    public String getLastStatusCode()
    {
        return this.lastStatusCode;
    }

    public void setLastStatusCode(final String inlastStatusCode)
    {
        this.lastStatusCode = inlastStatusCode;
    }

    public Date getLastupdateddate()
    {
        return this.lastupdateddate;
    }

    public void setLastupdateddate(final Date inlastupdateddate)
    {
        this.lastupdateddate = inlastupdateddate;
    }

    public String getLastUpdatedUserId()
    {
        return this.lastUpdatedUserId;
    }

    public void setLastUpdatedUserId(final String inlastUpdatedUserId)
    {
        this.lastUpdatedUserId = inlastUpdatedUserId;
    }

    public Long getMarketintelligenceid()
    {
        return this.marketintelligenceid;
    }

    public void setMarketintelligenceid(final Long inmarketintelligenceid)
    {
        this.marketintelligenceid = inmarketintelligenceid;
    }

    public String getMarketintelligencetype()
    {
        return this.marketintelligencetype;
    }

    public void setMarketintelligencetype(final String inmarketintelligencetype)
    {
        this.marketintelligencetype = inmarketintelligencetype;
    }

    public String getPurposeDescription()
    {
        return this.purposeDescription;
    }

    public void setPurposeDescription(final String inpurposeDescription)
    {
        this.purposeDescription = inpurposeDescription;
    }

    public String getSheetName()
    {
        return this.sheetName;
    }

    public void setSheetName(final String insheetName)
    {
        this.sheetName = insheetName;
    }

    public String getStccCode()
    {
        return this.stccCode;
    }

    public void setStccCode(final String instccCode)
    {
        this.stccCode = instccCode;
    }


    public String getCompetitor()
    {
        return competitor;
    }

    public void setCompetitor(final String competitor)
    {
        this.competitor = competitor;
    }

    public String getModeType()
    {
        return modeType;
    }

    public void setModeType(final String modeType)
    {
        this.modeType = modeType;
    }

    public String getEquipmentType()
    {
        return equipmentType;
    }

    public void setEquipmentType(final String equipmentType)
    {
        this.equipmentType = equipmentType;
    }

    public String getPriceQualifier()
    {
        return priceQualifier;
    }

    public void setPriceQualifier(final String priceQualifier)
    {
        this.priceQualifier = priceQualifier;
    }

    public String getUnitQualifier()
    {
        return unitQualifier;
    }

    public void setUnitQualifier(final String unitQualifier)
    {
        this.unitQualifier = unitQualifier;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	public Map getFullParmMap()
    {
        final Map parmMap = new HashMap();
        parmMap.put("marketintelligencefileid", marketintelligencefileid);
        parmMap.put("businessGroupName", businessGroupName);
        parmMap.put("businesssubgroupname", businesssubgroupname);
        parmMap.put("cifAlphaCode", cifAlphaCode);
        parmMap.put("cifSuffix", cifSuffix);
        parmMap.put("commodityDescription", commodityDescription);
        parmMap.put("creationdate", creationdate);
        parmMap.put("creationUserId", creationUserId);
        parmMap.put("currentProcessCode", currentProcessCode);
        parmMap.put("customerName", customerName);
        parmMap.put("fileName", fileName);
        parmMap.put("fileSizeValue", fileSizeValue);
        parmMap.put("fileType", fileType);
        parmMap.put("firmNumber", firmNumber);
        parmMap.put("headerRowNumber", headerRowNumber);
        parmMap.put("lastsaveddate", lastsaveddate);
        parmMap.put("lastStatusCode", lastStatusCode);
        parmMap.put("lastupdateddate", lastupdateddate);
        parmMap.put("lastUpdatedUserId", lastUpdatedUserId);
        parmMap.put("marketintelligenceid", marketintelligenceid);
        parmMap.put("marketintelligencetype", marketintelligencetype);
        parmMap.put("purposeDescription", purposeDescription);
        parmMap.put("sheetName", sheetName);
        parmMap.put("stccCode", stccCode);
        parmMap.put("competitor", competitor);
        parmMap.put("modeType", modeType);
        parmMap.put("equipmentType", equipmentType);
        parmMap.put("priceQualifier", priceQualifier);
        parmMap.put("unitQualifier", unitQualifier);
        return parmMap;
    }

    // @formatter:off
	public static final String FULL_INSERT_SQL = 
	" INSERT INTO NAF_MKT_INTL_SHT(" + 
		" MKT_INTL_SHT_ID," + 
		" BUS_GRP_NAME," + 
		" BUS_SUB_GRP_NAME," + 
		" CIF_ALPH_CODE," + 
		" CIF_SUFX," + 		
		" CMDY_DESC," + 
		" CRTN_DT," + 
		" CRTN_USER_ID," + 
		" CUR_PROC_CODE," + 
		" CUST_NAME," + 
		" FILE_NAME," + 
		" FILE_SIZE_VALU," + 
		" FILE_TYPE," + 
		" FIRM_NBR," + 
		" HDR_ROW_NBR," + 
		" LAST_SAVD_DT," + 
		" LAST_STAT_CODE," + 
		" LAST_UPTD_DT," + 
		" LAST_UPTD_USER_ID," + 
		" MKT_INTL_ID," + 
		" MKT_INTL_TYPE," + 
		" PURP_DESC," + 
		" XCEL_SHT_NAME," + 
		" STCC_CODE" + 
		")" + 
		" VALUES(" + 
		" :marketintelligencefileid," + 
		" :businessGroupName," + 
		" :businesssubgroupname," + 
		" :cifAlphaCode," + 
		" :cifSuffix," + 
		" :commodityDescription," + 
		" SYSDATE," + 
		" :creationUserId," + 
		" :currentProcessCode," + 
		" :customerName," + 
		" :fileName," + 
		" :fileSizeValue," + 
		" :fileType," + 
		" :firmNumber," + 
		" :headerRowNumber," + 
		" :lastsaveddate," + 
		" :lastStatusCode," + 
		" SYSDATE," + 
		" :creationUserId," + 
		" :marketintelligenceid," + 
		" :marketintelligencetype," + 
		" :purposeDescription," + 
		" :sheetName," + 
		" :stccCode" + 
		") ";

	public static final String FULL_INIT_SQL = 	"SELECT " + 
		" MKT_INTL_SHT_ID," + 
		" BUS_GRP_NAME," + 
		" BUS_SUB_GRP_NAME," + 
		" CIF_ALPH_CODE," + 
        " CIF_SUFX," +      
		" CMDY_DESC," + 
		" CRTN_DT," + 
		" CRTN_USER_ID," + 
		" CUR_PROC_CODE," + 
		" CUST_NAME," + 
		" FILE_NAME," + 
		" FILE_SIZE_VALU," + 
		" FILE_TYPE," + 
		" FIRM_NBR," + 
		" HDR_ROW_NBR," + 
		" LAST_SAVD_DT," + 
		" LAST_STAT_CODE," + 
		" LAST_UPTD_DT," + 
		" LAST_UPTD_USER_ID," + 
		" MKT_INTL_ID," + 
		" MKT_INTL_TYPE," + 
		" PURP_DESC," + 
		" XCEL_SHT_NAME," + 
		" STCC_CODE," + 
		" BUS_COMP_NAME," +
		" UNIT_QLFR_TYPE," +
		" PRIC_QLFR_TYPE," +
		" EQMT_TYPE," +
		" MOVE_MODE_TYPE" +
		" from NAF_MKT_INTL_SHT" + 
		" Where " + 
		" MKT_INTL_SHT_ID = :marketintelligencefileid" + 
		 " " ;
	public static final String FULL_UPDATE_SQL = 	"UPDATE NAF_MKT_INTL_SHT SET " + 
		" BUS_GRP_NAME = :businessGroupName," + 
		" BUS_SUB_GRP_NAME = :businesssubgroupname," + 
		" CIF_ALPH_CODE = :cifAlphaCode," + 
        " CIF_SUFX = :cifSuffix," +      
		" CMDY_DESC = :commodityDescription," + 		
		" CUR_PROC_CODE = :currentProcessCode," + 
		" CUST_NAME = :customerName," + 	
		" FIRM_NBR = :firmNumber," + 
		" HDR_ROW_NBR = :headerRowNumber," + 
		" LAST_SAVD_DT = sysdate," + 		
		" LAST_UPTD_DT = sysdate," + 
		" LAST_UPTD_USER_ID = :lastUpdatedUserId," + 		
		" MKT_INTL_TYPE = :marketintelligencetype," + 
		" PURP_DESC = :purposeDescription," + 	
		" STCC_CODE = :stccCode," + 
		" BUS_COMP_NAME = :competitor," + 
		" UNIT_QLFR_TYPE = :unitQualifier," + 
		" PRIC_QLFR_TYPE = :priceQualifier," + 
		" EQMT_TYPE = :equipmentType," + 
		" MOVE_MODE_TYPE = :modeType" + 
		" Where " + 
		" MKT_INTL_SHT_ID = :marketintelligencefileid" + 
		" " ; 	
	   // @formatter:on   

    public static final String SEQUENCE_NEXTVAL = "select NAF_MKT_INTL_SHT_Q1.NEXTVAL from dual";


    @Override
    public String toString()
    {
        return " marketintelligencefileid: " + this.marketintelligencefileid + "\n" + " businessGroupName: " +
            this.businessGroupName + "\n" + " businesssubgroupname: " + this.businesssubgroupname + "\n" +
            " cifAlphaCode: " + this.cifAlphaCode + "\n" + " commodityDescription: " + this.commodityDescription +
            "\n" + " creationdate: " + this.creationdate + "\n" + " creationUserId: " + this.creationUserId + "\n" +
            " currentProcessCode: " + this.currentProcessCode + "\n" + " customerName: " + this.customerName + "\n" +
            " fileName: " + this.fileName + "\n" + " fileSizeValue: " + this.fileSizeValue + "\n" + " fileType: " +
            this.fileType + "\n" + " firmNumber: " + this.firmNumber + "\n" + " headerRowNumber: " +
            this.headerRowNumber + "\n" + " lastsaveddate: " + this.lastsaveddate + "\n" + " lastStatusCode: " +
            this.lastStatusCode + "\n" + " lastupdateddate: " + this.lastupdateddate + "\n" + " lastUpdatedUserId: " +
            this.lastUpdatedUserId + "\n" + " marketintelligenceid: " + this.marketintelligenceid + "\n" +
            " marketintelligencetype: " + this.marketintelligencetype + "\n" + " purposeDescription: " +
            this.purposeDescription + "\n" + " sheetName: " + this.sheetName + "\n" + " stccCode: " + this.stccCode +
            "\n" + "";
    }

}
