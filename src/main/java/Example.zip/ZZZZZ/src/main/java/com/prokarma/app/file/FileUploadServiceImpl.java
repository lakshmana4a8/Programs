package com.prokarma.app.file;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.prokarma.app.json.entity.DataColumn;
import com.prokarma.app.json.entity.DataRow;

@Service
public class FileUploadServiceImpl implements FileUploadService{
	
	@Autowired
    private Environment environment;

	@Override
	public List<DataRow> handleFileUpload(MultipartFile file) {
		final String fileName = (String) retrieveValueFromMethod(file, "getOriginalFilename");
		writeFileIntoFileSystem(file, fileName);
		extractFileExtension(fileName);
		return readFileData(file, fileName);
	}
	
	private void writeFileIntoFileSystem(final MultipartFile file, final String fileName) {
        BufferedOutputStream outputStream = null;
        try {
            final String directoryPath = format(environment.getProperty("user.directory"), "xprk259");
            final File userDirectory = new File(directoryPath);
            if (!userDirectory.exists()) {
                userDirectory.mkdirs();
            }
            byte[] bytes = file.getBytes();
            outputStream = new BufferedOutputStream(new FileOutputStream(new File(userDirectory, fileName)));
            outputStream.write(bytes);
        }
        catch (final Exception e) {
            throw new RuntimeException(e);
        }
        finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                }
                catch (final IOException e) {
                }
            }
        }
    }
	
	private List<DataRow> readFileData(MultipartFile file, String fileName) {
		List<DataRow> dataRowsList = new ArrayList<DataRow>();
		if (FilenameUtils.isExtension(fileName, "xls") || FilenameUtils.isExtension(fileName, "xlsx")) {
			final Workbook workbook = retrieveWorkbook(file);
			final int numberOfSheets = workbook.getNumberOfSheets();
			for (int index = 0; index < numberOfSheets; index++)
            {
                final Sheet sheet = workbook.getSheetAt(index);
                getAllData(sheet);
                getFirstRow(sheet);
            }
        }else if (FilenameUtils.isExtension(fileName, "csv") || FilenameUtils.isExtension(fileName, "txt")) {
            String delimited;
            if (FilenameUtils.isExtension(fileName, "txt")) {
                delimited = "\t";
            }
            else {
                delimited = ",";
            }
            dataRowsList = readCSVFileOrTXTFile(file,delimited);
        }
		return dataRowsList;
	}
	
	private List<DataRow> readCSVFileOrTXTFile(MultipartFile file, String delimited) {
		InputStream inputStream = null;
        Reader reader = null;
        BufferedReader bufferReader = null;
        final List<DataRow> fieldDataRowList = new ArrayList<DataRow>();
        try{
        	inputStream = file.getInputStream();
            reader = new InputStreamReader(inputStream);
            bufferReader = new BufferedReader(reader);
            String sCurrentLine = "";
            while ((sCurrentLine = bufferReader.readLine()) != null) {
            	List<DataColumn> dataColumns = new ArrayList<DataColumn>();
            	final DataRow fieldDataRow = new DataRow();
            	String[] data = sCurrentLine.split(delimited);
            	int columnCount = 1;
            	for(String attributeValue : data){
					DataColumn dataColumn = new DataColumn();
					dataColumn.setColumnIndex(columnCount);
					dataColumn.setColumnValue(attributeValue);
					dataColumns.add(dataColumn);
					columnCount++;
				}
            	fieldDataRow.setDataColumn(dataColumns);
            	fieldDataRowList.add(fieldDataRow);
            }
            return fieldDataRowList;
        }catch (final Exception e) {
            throw new RuntimeException(e);
        }
        finally {
            try {
                if (bufferReader != null) {
                    bufferReader.close();
                }
                if (reader != null) {
                    reader.close();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            catch (final IOException e) {
            }
        }
	}

	private void getFirstRow(Sheet sheet) {
		final List<Object> mappingDataModelList = new ArrayList<Object>();
        for (final Row row : sheet) {
            for (final Cell cell : row) {
                final DataFormatter dataFormatter = new DataFormatter();
                // CellReference cellReference = new CellReference(dataCell);
                final String cellValue = dataFormatter.formatCellValue(cell);
                mappingDataModelList.add(cellValue);
            }
            break;
        }
	}

	private void getAllData(Sheet sheet) {
        final List<Object> fieldDataModelList = new ArrayList<Object>();
        for (final Row row : sheet)
        {
            final List<String> dataList = new ArrayList<String>();
            for (final Cell cell : row)
            {
                final DataFormatter dataFormatter = new DataFormatter();
                // CellReference cellReference = new CellReference(dataCell);
                final String cellValue = dataFormatter.formatCellValue(cell);
                dataList.add(cellValue);
            }
            fieldDataModelList.add(JSONArray.toJSONString(dataList));
        }
	}

	private Workbook retrieveWorkbook(MultipartFile file) {
		InputStream inputStream = null;
        Workbook workbook = null;
        try {
            inputStream = file.getInputStream();
            workbook = WorkbookFactory.create(inputStream);
        }
        catch (final Exception e) {
            throw new RuntimeException(e);
        }
        finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                }
                catch (final IOException e) {
                }
            }
        }
        return workbook;
	}

	public static String format(final String pattern, final Object... arguments) {
        return MessageFormat.format(pattern, arguments);
    }
	//for getting the file name from File
    private Object retrieveValueFromMethod(final Object object, final String methodName) {
        final Method method = ReflectionUtils.findMethod(object.getClass(), methodName);
        try {
            final Object resultObject = ReflectionUtils.invokeMethod(method, object);
            System.out.println("-------file name---------");
            System.out.println(resultObject);
            System.out.println("--------file name--------");
            return resultObject;
        }
        catch (final IllegalArgumentException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static String extractFileExtension(final String fileName) {
        final int dotInd = fileName.lastIndexOf(".");
        // if dot is in the first position,
        // we are dealing with a hidden file rather than an extension
        return (dotInd > 0 && dotInd < fileName.length()) ? fileName.substring(dotInd + 1) : null;
    }
}
