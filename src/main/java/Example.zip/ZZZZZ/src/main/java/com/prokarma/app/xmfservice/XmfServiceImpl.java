package com.prokarma.app.xmfservice;

import java.io.Serializable;

import org.acegisecurity.context.SecurityContextHolder;
import org.acegisecurity.providers.AbstractAuthenticationToken;
import org.acegisecurity.providers.ProviderManager;
import org.acegisecurity.providers.UsernamePasswordAuthenticationToken;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.aop.target.CommonsPoolTargetSource;
//import org.springframework.aop.target.CommonsPoolTargetSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.security.core.CyberArkUserDetailsService;
import com.uprr.app.xmf.client.security.core.UserPwdDetails;

@Service
public class XmfServiceImpl implements XmfService, Serializable{
	
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = LogManager.getLogger(XmfServiceImpl.class);
	
	private static long SERVICE_TIMEOUT = 60000L;
	
	@Autowired
	private ProviderManager providerManager;
	
	@Autowired
    private CyberArkUserDetailsService cyberArkUserDetailsService;
	
	@Autowired
    private MessageUtilities messageUtilities;
	
	@Autowired
	private CommonsPoolTargetSource commonsPoolTargetSource;
	
	private @Value("${xmf.clientId}") String clientId;

	public String sendXmfRequest(final String serviceName, final String requestXML) {
		System.out.println("in xmf");
		final ServiceProxy serviceProxy = checkOut();
		
		final String header = messageUtilities.createXMFRequestHeader(clientId, serviceName);
		final String request = messageUtilities.createXMFMessage(header, requestXML);
		
		
		String responseXML = null;
        String response = null;
        try {
			response = serviceProxy.invoke(request, SERVICE_TIMEOUT);
			LOGGER.info("Output XML: " + response);
			if(response == null){
				throw new Exception("got response as null");
			}
			responseXML = messageUtilities.getXMFBody(response);
            if (messageUtilities.isFault(responseXML)) {
                final String sFault = messageUtilities.getFaultDetail(responseXML);
                final Exception error = new Exception("The call to " + responseXML + " failed. Fault String = " +
                    sFault);
                LOGGER.error("XMFServiceImpl.sendXMFRequest() -  Call to " + serviceName +
                    " returned a Fault. Duration: Fault String" + sFault);
                throw error;
            }
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
            // clean up has to be performed
            if (serviceProxy != null) {
                checkIn(serviceProxy);
            }
        }
        return responseXML;
	}
	
	public ServiceProxy checkOut() {
        ServiceProxy serviceProxy = null;
        try {
            serviceProxy = (ServiceProxy) commonsPoolTargetSource.getTarget();
        } catch (final Exception e) {
            LOGGER.error("Method Name checkOut(), Exception " + e.getMessage(), e);
        }
        return serviceProxy;
    }

    public void checkIn(final ServiceProxy serviceProxy) {
        try {
        	commonsPoolTargetSource.releaseTarget(serviceProxy);
        } catch (final Exception e) {
            LOGGER.error("Method Name checkIn(), Exception :" + e.getMessage(), e);
        }
    }

	@Override
	public String getStringVal(String val) {
		return "lakshmnananannana"+clientId;
	}
	
	private void xmfAuthentication() {
        try {
            final String user = cyberArkUserDetailsService.getAppId();
            final String pwdToken = cyberArkUserDetailsService.getToken();
            if (pwdToken == null)
            {
                throw new Exception("Unable to retrieve password from Vault for user -> " + user);
            }
            final UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(user, pwdToken);
            final AbstractAuthenticationToken authn = (AbstractAuthenticationToken) providerManager.authenticate(token);
            authn.setDetails(new UserPwdDetails());
            SecurityContextHolder.getContext().setAuthentication(authn);
        }
        catch (final Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public String sendSecureXmfRequest(String serviceName, String requestXML) {
        xmfAuthentication();
        return sendXmfRequest(serviceName, requestXML);
    }

}
