package aaaaaaa;

public class Iii {
    public static void main(String[] args) {
        String s = "internationalization";
        System.out.println("aaaaaaaa");
        for (int i = 0; i < s.length(); i++) {
            System.out.println(s.substring(0, i)+""+(s.length()-(i+2))+""+s.substring(((i+1)), s.length()));
        }
    }
}
