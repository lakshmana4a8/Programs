package com.prokarma.appconfig.springconfig;

import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;

import com.prokarma.app.utils.CyberArkUtil;
import com.prokarma.app.utils.EnvironmentUtil;

@Configuration
public class AppJmsConfiguration
{

    @Autowired
    private Environment environment;

    private String jms_Connection_Factory = "jms.intial.connection.factory";
    private String tibco_Url = "tibco.url";
    private String tibco_username = "tibco.username";
    private String developerJMSKey = "tibco.key";
    private String ena_connectionFactory = "ena.connectionFactory";
    private String ena_queue = "ena.queue";


    @Bean
    public JndiTemplate jndiTemplate()
    {
        final JndiTemplate jndiTemplate = new JndiTemplate();
        final Properties properties = new Properties();
        properties.setProperty("java.naming.factory.initial", environment.getProperty(jms_Connection_Factory));
        properties.setProperty("java.naming.provider.url", environment.getProperty(tibco_Url));
        properties.setProperty("java.naming.security.principal", environment.getProperty(tibco_username));
        properties.setProperty("java.naming.security.credentials", retrieveJMSPassword());
        jndiTemplate.setEnvironment(properties);
        return jndiTemplate;
    }

    @Bean
    public ConnectionFactory connectionFactory()
    {
        final JndiObjectFactoryBean factoryBean = new JndiObjectFactoryBean();
        factoryBean.setJndiName(environment.getProperty(ena_connectionFactory));
        factoryBean.setJndiTemplate(jndiTemplate());
        try
        {
            factoryBean.afterPropertiesSet();
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return (ConnectionFactory) factoryBean.getObject();

    }

    @Bean
    public Destination enaNotificationQueue()
    {
        final JndiObjectFactoryBean factoryBean = new JndiObjectFactoryBean();
        factoryBean.setJndiName(environment.getProperty(ena_queue));
        factoryBean.setJndiTemplate(jndiTemplate());
        try
        {
            factoryBean.afterPropertiesSet();
        }
        catch (final Exception e)
        {
            throw new RuntimeException(e);
        }
        return (Destination) factoryBean.getObject();
    }

    @Bean
    public UserCredentialsConnectionFactoryAdapter enaQueueConnectionFactory()
    {
        final UserCredentialsConnectionFactoryAdapter factoryBean = new UserCredentialsConnectionFactoryAdapter();
        factoryBean.setUsername(environment.getProperty(tibco_username));
        factoryBean.setPassword(retrieveJMSPassword());
        factoryBean.setTargetConnectionFactory(connectionFactory());
        return factoryBean;
    }

    @Bean
    public JmsTemplate enaJmsTemplate()
    {
        final JmsTemplate factoryBean = new JmsTemplate();
        factoryBean.setConnectionFactory(enaQueueConnectionFactory());
        factoryBean.setDefaultDestination(enaNotificationQueue());
        return factoryBean;
    }

    private String retrieveJMSPassword()
    {
        if (EnvironmentUtil.isLocal())
        {
            return environment.getProperty(developerJMSKey);
        }
        return CyberArkUtil.retrieveJMSPassword(environment.getProperty(tibco_username));
    }

}
