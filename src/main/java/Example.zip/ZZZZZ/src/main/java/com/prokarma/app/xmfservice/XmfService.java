package com.prokarma.app.xmfservice;

public interface XmfService {
	String sendXmfRequest(final String serviceName, final String requestXML);
	String getStringVal(final String val);
	String sendSecureXmfRequest(String serviceName, String requestXML);
}
