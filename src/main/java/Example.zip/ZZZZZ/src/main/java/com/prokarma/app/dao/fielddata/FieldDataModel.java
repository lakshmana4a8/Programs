package com.prokarma.app.dao.fielddata;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class FieldDataModel
{

    public static final Integer COMPLEX_PRIMARY_KEY = 0;
    public static final String PRIMARY_KEY_COLUMN_PARAMETER = "fielddataid";
    public static final String ROWMAPPER_CLASS_NAME = "com.uprr.app.naf.dao.fielddata.FieldDataRowMapper";
    /**
     * FLD_DATA_ID 0 NUMBER
     **/
    private Long fieldDataId;


    /**
     * CRTN_DT null DATE
     **/
    private Date creationdate;


    /**
     * CRTN_USER_ID null VARCHAR2
     **/
    private String creationUserId;


    /**
     * LAST_UPTD_DT null DATE
     **/
    private Date lastupdateddate;


    /**
     * LAST_UPTD_USER_ID null VARCHAR2
     **/
    private String lastUpdatedUserId;


    /**
     * MKT_INTL_FILE_ID 0 NUMBER
     **/
    private Long marketintelligencefileid;


    /**
     * RAW_DATA null VARCHAR2
     **/
    private String rawData;


    /**
     * SRC_ROW_NBR 0 NUMBER
     **/
    private Integer sourceRowNumber;


    public Long getFieldDataId()
    {
        return this.fieldDataId;
    }

    public void setFieldDataId(final Long fieldDataId)
    {
        this.fieldDataId = fieldDataId;
    }

    public Date getCreationdate()
    {
        return this.creationdate;
    }

    public void setCreationdate(final Date increationdate)
    {
        this.creationdate = increationdate;
    }

    public String getCreationUserId()
    {
        return this.creationUserId;
    }

    public void setCreationUserId(final String increationUserId)
    {
        this.creationUserId = increationUserId;
    }

    public Date getLastupdateddate()
    {
        return this.lastupdateddate;
    }

    public void setLastupdateddate(final Date inlastupdateddate)
    {
        this.lastupdateddate = inlastupdateddate;
    }

    public String getLastUpdatedUserId()
    {
        return this.lastUpdatedUserId;
    }

    public void setLastUpdatedUserId(final String inlastUpdatedUserId)
    {
        this.lastUpdatedUserId = inlastUpdatedUserId;
    }

    public Long getMarketintelligencefileid()
    {
        return this.marketintelligencefileid;
    }

    public void setMarketintelligencefileid(final Long inmarketintelligencefileid)
    {
        this.marketintelligencefileid = inmarketintelligencefileid;
    }

    public String getRawData()
    {
        return this.rawData;
    }

    public void setRawData(final String inrawData)
    {
        this.rawData = inrawData;
    }

    public Integer getSourceRowNumber()
    {
        return this.sourceRowNumber;
    }

    public void setSourceRowNumber(final Integer insourceRowNumber)
    {
        this.sourceRowNumber = insourceRowNumber;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Map getFullParmMap()
    {
        final Map parmMap = new HashMap();
        parmMap.put("fielddataid", fieldDataId);
        parmMap.put("creationdate", creationdate);
        parmMap.put("creationuserid", creationUserId);
        parmMap.put("lastupdateddate", lastupdateddate);
        parmMap.put("lastupdateduserid", lastUpdatedUserId);
        parmMap.put("marketintelligencefileid", marketintelligencefileid);
        parmMap.put("rawdata", rawData);
        parmMap.put("sourcerownumber", sourceRowNumber);
        return parmMap;
    }

    // @formatter:off
	public static final String FULL_INSERT_SQL = 
	" INSERT INTO NAF_FLD_DATA(" + 
		" FLD_DATA_ID," + 
		" CRTN_DT," + 
		" CRTN_USER_ID," + 
		" LAST_UPTD_DT," + 
		" LAST_UPTD_USER_ID," + 
		" MKT_INTL_SHT_ID," + 
		" RAW_DATA," + 
		" SHT_ROW_NBR" + 
		")" + 
		" VALUES(" + 
		" NAF_FLD_DATA_Q1.NEXTVAL," + 
		" SYSDATE," + 
		" :creationUserId," + 
		" SYSDATE," + 
		" :creationUserId," + 
		" :marketintelligencefileid," + 
		" :rawData," + 
		" :sourceRowNumber" + 
		") ";

	public static final String FULL_INIT_SQL = 	"SELECT " + 
		" FLD_DATA_ID," + 
		" CRTN_DT," + 
		" CRTN_USER_ID," + 
		" LAST_UPTD_DT," + 
		" LAST_UPTD_USER_ID," + 
		" MKT_INTL_SHT_ID," + 
		" RAW_DATA," + 
		" SHT_ROW_NBR" + 
		" from NAF_FLD_DATA" + 
		" Where " + 
		" FLD_DATA_ID = :fielddataid" + 
		 " " ;
	public static final String FULL_UPDATE_SQL = 	"UPDATE NAF_FLD_DATA SET" + 
		" CRTN_DT = :creationdate," + 
		" CRTN_USER_ID = :creationuserid," + 
		" LAST_UPTD_DT = :lastupdateddate," + 
		" LAST_UPTD_USER_ID = :lastupdateduserid," + 
		" MKT_INTL_SHT_ID = :marketintelligencefileid," + 
		" RAW_DATA = :rawdata," + 
		" SHT_ROW_NBR = :sourcerownumber" + 
		" Where " + 
		" FLD_DATA_ID = :fielddataid" + 
		" " ; 
	
	public static final String SEQUENCE_NEXTVAL = "select NAF_FLD_DATA_Q1.NEXTVAL from dual";
	// @formatter:on 


    @Override
    public String toString()
    {
        return " fieldDataId: " + this.fieldDataId + "\n" + " creationdate: " + this.creationdate + "\n" +
            " creationUserId: " + this.creationUserId + "\n" + " lastupdateddate: " + this.lastupdateddate + "\n" +
            " lastUpdatedUserId: " + this.lastUpdatedUserId + "\n" + " marketintelligencefileid: " +
            this.marketintelligencefileid + "\n" + " rawData: " + this.rawData + "\n" + " sourceRowNumber: " +
            this.sourceRowNumber + "\n" + "";
    }

}
