package com.prokarma.app.dao.procque;

import java.util.Date;
import java.util.Map;
import java.util.HashMap;

public class ProcQueModel {

	public static final Integer COMPLEX_PRIMARY_KEY = 0;
	public static final String PRIMARY_KEY_COLUMN_PARAMETER = "processqueueid";
	public static final String ROWMAPPER_CLASS_NAME="com.prokarma.app.dao.procque.ProcQueRowMapper";
	private Integer processQueueId;
	private Integer lockIndicator;
	private Date processEndTimestamp;
	private String processHostName;
	private Integer processIndicator;
	private String processJobTypeCode;
	private String processKeyed1Text;
	private String processKeyed2Text;
	private String processKeyed3Text;
	private String processKeyed4Text;
	private String processKeyed5Text;
	private String processObjectId;
	private String processStatusMessageText;
	private Date processStartsTimestamp;
	private String processUnitText;


	public Integer getProcessQueueId() {
		return this.processQueueId;
	}

	public void setProcessQueueId(Integer inprocessQueueId) {
		this.processQueueId = inprocessQueueId;
	}

	public Integer getLockIndicator() {
		return this.lockIndicator;
	}

	public void setLockIndicator(Integer inlockIndicator) {
		this.lockIndicator = inlockIndicator;
	}

	public Date getProcessEndTimestamp() {
		return this.processEndTimestamp;
	}

	public void setProcessEndTimestamp(Date inprocessEndTimestamp) {
		this.processEndTimestamp = inprocessEndTimestamp;
	}

	public String getProcessHostName() {
		return this.processHostName;
	}

	public void setProcessHostName(String inprocessHostName) {
		this.processHostName = inprocessHostName;
	}

	public Integer getProcessIndicator() {
		return this.processIndicator;
	}

	public void setProcessIndicator(Integer inprocessIndicator) {
		this.processIndicator = inprocessIndicator;
	}

	public String getProcessJobTypeCode() {
		return this.processJobTypeCode;
	}

	public void setProcessJobTypeCode(String inprocessJobTypeCode) {
		this.processJobTypeCode = inprocessJobTypeCode;
	}

	public String getProcessKeyed1Text() {
		return this.processKeyed1Text;
	}

	public void setProcessKeyed1Text(String inprocessKeyed1Text) {
		this.processKeyed1Text = inprocessKeyed1Text;
	}

	public String getProcessKeyed2Text() {
		return this.processKeyed2Text;
	}

	public void setProcessKeyed2Text(String inprocessKeyed2Text) {
		this.processKeyed2Text = inprocessKeyed2Text;
	}

	public String getProcessKeyed3Text() {
		return this.processKeyed3Text;
	}

	public void setProcessKeyed3Text(String inprocessKeyed3Text) {
		this.processKeyed3Text = inprocessKeyed3Text;
	}

	public String getProcessKeyed4Text() {
		return this.processKeyed4Text;
	}

	public void setProcessKeyed4Text(String inprocessKeyed4Text) {
		this.processKeyed4Text = inprocessKeyed4Text;
	}

	public String getProcessKeyed5Text() {
		return this.processKeyed5Text;
	}

	public void setProcessKeyed5Text(String inprocessKeyed5Text) {
		this.processKeyed5Text = inprocessKeyed5Text;
	}

	public String getProcessObjectId() {
		return this.processObjectId;
	}

	public void setProcessObjectId(String inprocessObjectId) {
		this.processObjectId = inprocessObjectId;
	}

	public String getProcessStatusMessageText() {
		return this.processStatusMessageText;
	}

	public void setProcessStatusMessageText(String inprocessStatusMessageText) {
		this.processStatusMessageText = inprocessStatusMessageText;
	}

	public Date getProcessStartsTimestamp() {
		return this.processStartsTimestamp;
	}

	public void setProcessStartsTimestamp(Date inprocessStartsTimestamp) {
		this.processStartsTimestamp = inprocessStartsTimestamp;
	}

	public String getProcessUnitText() {
		return this.processUnitText;
	}

	public void setProcessUnitText(String inprocessUnitText) {
		this.processUnitText = inprocessUnitText;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map getFullParmMapWithArgs(Integer processqueueid,Integer lockindicator,Date processendtimestamp,String processhostname,Integer processindicator,String processjobtypecode,String processkeyed1text,String processkeyed2text,String processkeyed3text,String processkeyed4text,String processkeyed5text,String processobjectid,String processstatusmessagetext,Date processstartstimestamp,String processunittext){
		Map parmMap = new HashMap();
		parmMap.put("processqueueid",processqueueid);
		parmMap.put("lockIndicator",lockindicator);
		parmMap.put("processendtimestamp",processendtimestamp);
		parmMap.put("processhostname",processhostname);
		parmMap.put("processindicator",processindicator);
		parmMap.put("processjobtypecode",processjobtypecode);
		parmMap.put("processkeyed1text",processkeyed1text);
		parmMap.put("processkeyed2text",processkeyed2text);
		parmMap.put("processkeyed3text",processkeyed3text);
		parmMap.put("processkeyed4text",processkeyed4text);
		parmMap.put("processkeyed5text",processkeyed5text);
		parmMap.put("processobjectid",processobjectid);
		parmMap.put("processstatusmessagetext",processstatusmessagetext);
		parmMap.put("processstartstimestamp",processstartstimestamp);
		parmMap.put("processunittext",processunittext);
	return parmMap;
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map getFullParmMap() {
		Map parmMap = new HashMap();
		parmMap.put("processqueueid",processQueueId);
		parmMap.put("lockIndicator",lockIndicator);
		parmMap.put("processendtimestamp",processEndTimestamp);
		parmMap.put("processhostname",processHostName);
		parmMap.put("processindicator",processIndicator);
		parmMap.put("processjobtypecode",processJobTypeCode);
		parmMap.put("processkeyed1text",processKeyed1Text);
		parmMap.put("processkeyed2text",processKeyed2Text);
		parmMap.put("processkeyed3text",processKeyed3Text);
		parmMap.put("processkeyed4text",processKeyed4Text);
		parmMap.put("processkeyed5text",processKeyed5Text);
		parmMap.put("processobjectid",processObjectId);
		parmMap.put("processstatusmessagetext",processStatusMessageText);
		parmMap.put("processstartstimestamp",processStartsTimestamp);
		parmMap.put("processunittext",processUnitText);
	return parmMap;
	}
	public static final String fullInsertSQL = 
	" INSERT INTO NAF_PROC_QUE(" + 
		" PROC_QUE_ID," + 
		" LOCK_IND," + 
		" PROC_END_TMST," + 
		" PROC_HOST_NAME," + 
		" PROC_IND," + 
		" PROC_JOB_TYPE_CODE," + 
		" PROC_KEY_1_TEXT," + 
		" PROC_KEY_2_TEXT," + 
		" PROC_KEY_3_TEXT," + 
		" PROC_KEY_4_TEXT," + 
		" PROC_KEY_5_TEXT," + 
		" PROC_OBJ_ID," + 
		" PROC_STAT_MSG_TEXT," + 
		" PROC_STRT_TMST," + 
		" PROC_UNIT_TEXT" + 
		")" + 
		" VALUES(" + 
		" NAF_PROC_QUE_Q1.NEXTVAL," + 
		" :lockIndicator," +
		" :processEndTimestamp," + 
		" :processHostName," + 
		" :processIndicator," + 
		" :processJobTypeCode," + 
		" :processKeyed1Text," +
		" :processKeyed2Text," + 
		" :processKeyed3Text," + 
		" :processKeyed4Text," + 
		" :processKeyed5Text," + 
		" :processObjectId," + 
		" :processStatusMessageText," + 
		" :processStartsTimestamp," + 
		 " :processUnitText" + 
		") ";

	public static final String fullInitSQL = 	"SELECT " + 
		" PROC_QUE_ID," + 
		" LOCK_IND," + 
		" PROC_END_TMST," + 
		" PROC_HOST_NAME," + 
		" PROC_IND," + 
		" PROC_JOB_TYPE_CODE," + 
		" PROC_KEY_1_TEXT," + 
		" PROC_KEY_2_TEXT," + 
		" PROC_KEY_3_TEXT," + 
		" PROC_KEY_4_TEXT," + 
		" PROC_KEY_5_TEXT," + 
		" PROC_OBJ_ID," + 
		" PROC_STAT_MSG_TEXT," + 
		" PROC_STRT_TMST," + 
		" PROC_UNIT_TEXT" + 
		" from NAF_PROC_QUE" + 
		" Where " + 
		" PROC_QUE_ID = :processqueueid" + 
		 " " ;
	public static final String fullUpdateSQL = 	"UPDATE NAF_PROC_QUE" + 
		" LOCK_IND = :lockindicator," + 
		" PROC_END_TMST = :processendtimestamp," + 
		" PROC_HOST_NAME = :processhostname," + 
		" PROC_IND = :processindicator," + 
		" PROC_JOB_TYPE_CODE = :processjobtypecode," + 
		" PROC_KEY_1_TEXT = :processkeyed1text," + 
		" PROC_KEY_2_TEXT = :processkeyed2text," + 
		" PROC_KEY_3_TEXT = :processkeyed3text," + 
		" PROC_KEY_4_TEXT = :processkeyed4text," + 
		" PROC_KEY_5_TEXT = :processkeyed5text," + 
		" PROC_OBJ_ID = :processobjectid," + 
		" PROC_STAT_MSG_TEXT = :processstatusmessagetext," + 
		" PROC_STRT_TMST = :processstartstimestamp," + 
		" PROC_UNIT_TEXT = :processunittext" + 
		" Where " + 
		" PROC_QUE_ID = :processqueueid" + 
		" " ; 

	public static final String initSQLBy_processqueueid = 	"SELECT NAF_PROC_QUE" + 
		" LOCK_IND = :lockindicator," + 
		" PROC_END_TMST = :processendtimestamp," + 
		" PROC_HOST_NAME = :processhostname," + 
		" PROC_IND = :processindicator," + 
		" PROC_JOB_TYPE_CODE = :processjobtypecode," + 
		" PROC_KEY_1_TEXT = :processkeyed1text," + 
		" PROC_KEY_2_TEXT = :processkeyed2text," + 
		" PROC_KEY_3_TEXT = :processkeyed3text," + 
		" PROC_KEY_4_TEXT = :processkeyed4text," + 
		" PROC_KEY_5_TEXT = :processkeyed5text," + 
		" PROC_OBJ_ID = :processobjectid," + 
		" PROC_STAT_MSG_TEXT = :processstatusmessagetext," + 
		" PROC_STRT_TMST = :processstartstimestamp," + 
		" PROC_UNIT_TEXT = :processunittext" + 
		" Where " + 
		" PROC_QUE_ID = :processqueueid" + 
		" " ; 


	@Override
	public String toString() {
	return 
 		 " processQueueId: "  + this.processQueueId +"\n"+
 		 " lockIndicator: "  + this.lockIndicator +"\n"+
 		 " processEndTimestamp: "  + this.processEndTimestamp +"\n"+
 		 " processHostName: "  + this.processHostName +"\n"+
 		 " processIndicator: "  + this.processIndicator +"\n"+
 		 " processJobTypeCode: "  + this.processJobTypeCode +"\n"+
 		 " processKeyed1Text: "  + this.processKeyed1Text +"\n"+
 		 " processKeyed2Text: "  + this.processKeyed2Text +"\n"+
 		 " processKeyed3Text: "  + this.processKeyed3Text +"\n"+
 		 " processKeyed4Text: "  + this.processKeyed4Text +"\n"+
 		 " processKeyed5Text: "  + this.processKeyed5Text +"\n"+
 		 " processObjectId: "  + this.processObjectId +"\n"+
 		 " processStatusMessageText: "  + this.processStatusMessageText +"\n"+
 		 " processStartsTimestamp: "  + this.processStartsTimestamp +"\n"+
 		 " processUnitText: "  + this.processUnitText +"\n"+
		"";
	}


}